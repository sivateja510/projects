const express = require('express');
const cors = require('cors');
const monk = require('monk');
const server = express();
const PORT = 8090;
server.use(cors());
server.use(express.json());
const urll = ('mongodb+srv://sivateja:sivateja@facultydairy.wqm3eo7.mongodb.net/MediFinder');
const db = monk(urll);
const entr = db.get('Entire');
db.then(() => {
    console.log("db connected");

})
const entrq = db.get('AllMedcines');


server.get('/', (req, res) => {
    res.status(200);
    res.send(" server is running ");
});


server.get('/entrq', (req, res) => {
    entrq.find({}).then((docs) => {
        res.json(docs);
    });
})


server.post('/entrrq', async (req, res) => {
    try {
        const datar = db.get('AllMedcines');
        const updateData = {};
        updateData[req.body.type] = req.body.combinedData;

        await datar.update({ _id: req.body.id }, { $set: updateData });
        
        console.log(res.status); // This logs the status code function, not the actual status code
        res.status(200).json({ message: 'Data updated successfully' });
    } catch (error) {
        console.error('Error updating entries:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

server.get('/entry', (req, res) => {
    entr.find({}).then((docs) => {
        res.json(docs);
    });
})
const entri = db.get("AllMedcines");
server.get('/entryA', (req, res) => {
    entri.find({}).then((docs) => {
        res.json(docs);
    });
})

server.get('/entry/:id', (req, res) => {
    const entryId = req.params.id;
    entr.findOne({ _id: entryId }).then((doc) => {
        if (doc) {
            res.json(doc);
        } else {
            res.status(404).json({ message: "Entry not found" });
        }
    }).catch((error) => {
        console.error(error);
        res.status(500).json({ message: "Internal server error" });
    });
});


server.post('/entryy', async (req, res) => {
    try {
        const datar = db.get('Entire');
        await datar.update({ _id: req.body.id }, { $set: req.body });
        console.log(req.body)
    } catch (error) {
        console.error('Error updating patient:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
server.post('/entryym', async (req, res) => {
    try {
        const datar = db.get('Entire');
        const Tablets = req.body.push;
        await datar.update({ _id: req.body.id }, { $set: { orders: Tablets} });
        console.log(req.body.id)
    } catch (error) {
        console.error('Error updating patient:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
server.post('/entryxx', async (req, res) => {
    try {
        const datar = db.get('Entire');
        const Tablets = req.body.Tablets;
        await datar.update({ _id: req.body.id }, { $set: { Tablets: Tablets } });
        console.log(res.status)
        res.status(200).json({ message: 'Data updated successfully' });
    } catch (error) {
        console.error('Error updating entries:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
server.post('/entryxy', async (req, res) => {
    try {
        const datar = db.get('Entire');
        const cartItems = req.body.cartItem;
        await datar.update({ _id: req.body.id }, { $set: { orders: cartItems } });
        console.log(cartItems)
        res.status(200).json({ message: 'Data updated successfully' });
    } catch (error) {
        console.error('Error updating entries:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

server.post('/entryxyz', async (req, res) => {
    try {
        const datar = db.get('Entire');
        const cartItems = req.body.updatedCart;
        await datar.update({ _id: req.body.id }, { $set: { cart: cartItems } });
        console.log(res.status)
        res.status(200).json({ message: 'Data updated successfully' });
    } catch (error) {
        console.error('Error updating entries:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});


server.post('/entryxyzz', async (req, res) => {
    try {
        const datar = db.get('Entire');
        const cartItems = req.body.order;
        
        await datar.update({ _id: req.body.id }, { $set: { orders: cartItems } });
        console.log(res.status)
        res.status(200).json({ message: 'Data updated successfully' });
    } catch (error) {
        console.error('Error updating entries:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

server.post('/entryin', async (req, res) => {
    try {
        const datar = db.get('Entire');
        await datar.insert(req.body);
        console.log(res.statusCode); // Log status code before sending the response
        res.status(200).json({ message: 'Data inserted successfully' });
    } catch (error) {
        console.error(error); // Log the error for debugging
        res.status(500).json({ error: 'Internal server error' });
    }
});

server.delete('/entry/:id', async (req, res) => {
    try {
        const entryId = req.params.id;
        await entr.remove({ _id: entryId });
        res.status(200).json({ message: 'Entry deleted successfully' });
    } catch (error) {
        console.error('Error deleting entry:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});



server.listen(PORT, (error) => {
    if (!error)
        console.log("Server is Successfully Running,and server is listening on port " + PORT)
    else
        console.log("Error occurred, server can't start", error);
}
);



import React, { useState } from "react";
 
export const Context = React.createContext();
export const ContextProvider = ({ children, data }) => {
    const [items, setItems] = useState(data);

    return (
        <Context.Provider value={{ items, setItems }}>
            {children}
        </Context.Provider>
    );
};

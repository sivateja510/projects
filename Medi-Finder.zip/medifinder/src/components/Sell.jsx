import React, { useState, useEffect } from "react";
import NavSub from "./NavSub";
import img from '../Assets/reactangle.png';
import Footer from "./Footer";
import axios from "axios";

const Sell = () => {
    const [medicineOptions, setMedicineOptions] = useState([]);
    const [quantity, setQuantity] = useState(1); // Set default quantity to 1
    const [medicine, setMedicine] = useState("");
    const [tableData, setTableData] = useState([]);
    const [loading, setLoading] = useState(true); // State to manage loading status
    const id = JSON.parse(localStorage.getItem("id"));

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`http://localhost:8090/entry/${id}`);
                setMedicineOptions(response.data.Tablets);
                setLoading(false); // Set loading to false once data is fetched
            } catch (error) {
                console.error("Error fetching options:", error);
            }
        };

        fetchData();
    }, [id]); // Added id as a dependency to useEffect

    const handleAdd = () => {
        if (!quantity || !medicineOptions.length) {
            alert("Please select a medicine and enter quantity.");
            return;
        }

        const existingEntryIndex = tableData.findIndex(entry => entry.medicine === medicine);
        if (existingEntryIndex !== -1) {
            const updatedTableData = [...tableData];
            updatedTableData[existingEntryIndex].quantity += parseInt(quantity);
            setTableData(updatedTableData);
        } else {
            const newEntry = { medicine: medicine, quantity: parseInt(quantity) };
            setTableData([...tableData, newEntry]);
        }
        setQuantity(1); // Reset quantity to 1 after adding
    };

    const handleDelete = (index) => {
        const updatedTableData = [...tableData];
        updatedTableData.splice(index, 1);
        setTableData(updatedTableData);
    };


    const handleSubmit = async (ev) => {
        const updatedMedicineOptions = medicineOptions.map(med => {
            const soldMedicine = tableData.find(data => data.medicine === med.medicine);
            if (soldMedicine) {
                const newQuantity = med.quantity - soldMedicine.quantity;
                if (newQuantity < 0) {
                    alert(`Not enough stock available for ${med.medicine}`);
                    
                    window.location.reload();
                    // ev.preventdefault();
                    // throw new Error(`Not enough stock available for ${med.medicine}`);
                }
                return {
                    ...med,
                    quantity: newQuantity
                };
            }
            return med;
        });
    
        try {
            await axios.post("http://localhost:8090/entryxx", { id, Tablets: updatedMedicineOptions });
            alert("Data submitted successfully");
            console.log("Modified Medicine Options:", updatedMedicineOptions);
    
            setTableData([]);
            setMedicineOptions(updatedMedicineOptions);
        } catch (error) {
            console.error("Error submitting data:", error);
            alert("Failed to submit data. Please try again.");
        }
    };
    




    return (
        <>
            <NavSub />
            <div className="fluid-container homestart">
                <img src={img} alt='image' className="imag" />
                <div className="home">
                    <div className="container py-4 cont1">
                        <div className="row justify-content-around align-items-center mx-2">
                            <div className="col-lg-4 col-md-4 col-sm-10 col-xs-8">
                                <label htmlFor="medicine" className="form-label labell">Medicine</label>
                                {loading ? ( // Display loader while loading data
                                    <p>Loading medicine options...</p>
                                ) : (
                                    <select className="form-control" id="medicine" style={{ backgroundColor: "#ececec" }} onChange={(e) => setMedicine(e.target.value)}>
                                        <option value="">Select one</option>
                                        {medicineOptions.map((medicine, index) => (
                                            <option key={index} value={medicine.medicine}>
                                                {medicine.medicine}
                                            </option>
                                        ))}
                                    </select>
                                )}
                            </div>

                            <div className="col-lg-4 col-md-4 col-sm-10 col-xs-8">
                                <label htmlFor="quantity" className="form-label labell">Quantity</label>
                                <input type="number" className="form-control" id="quantity" placeholder="Enter Here.." style={{ backgroundColor: "#ececec" }} value={quantity} onChange={(e) => setQuantity(e.target.value)} min={1} />
                            </div>
                        </div>
                        <div className="d-flex align-items-center justify-content-center mt-4">
                            <button className="btn btn-primary btn-sm rounded-pill px-5" onClick={handleAdd}>Add</button>
                        </div>
                    </div>

                    <div className="container py-4 cont2">
                        <h5 className="mb-4">Sold medicines</h5>
                        <div className="table-responsive">
                            <table className="table table-bordered table-hover rounded custom-table">
                                <thead className="bg-primary text-white font-weight-bold">
                                    <tr>
                                        <th className="text-center">Medicine</th>
                                        <th className="text-center">Quantity</th>
                                        <th className="text-center">Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {tableData.map((data, index) => (
                                        <tr key={index}>
                                            <td className="text-center">{data.medicine}</td>
                                            <td className="text-center">{data.quantity}</td>
                                            <td className="text-center">
                                                <button className="btn btn-danger btn-sm" onClick={() => handleDelete(index)}>Delete</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div className="d-flex align-items-center justify-content-center m-2">
                        <button className="btn btn-primary btn-sm rounded-pill px-5" onClick={handleSubmit}>Submit</button>
                    </div>
                    <Footer />
                </div>
            </div>
        </>
    );
};

export default Sell;

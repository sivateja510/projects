import React, { useState } from "react";
import NavSub from "./NavSub";
import axios from "axios";
const ManageProducts = () => {
    const [formData, setFormData] = useState({
        UserName: "",
        Password: "",
        DL: "",
        GST: "",
        Email: "",
        Type: "",
        place: "",
        Address: "",
        Pic: "",
        Mobile: "",
        id: "",
        confirmPassword: "",
        newPassword: "",
        Name: "",
        Tablets: [],
        cart: [],
        orders: []
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = async(e) => {
        e.preventDefault();
        // Post data logic here
        try {
            await axios.post("http://localhost:8090/entryin", formData);
            alert("Data submitted successfully");
        } catch (error) {
            console.error("Error submitting data:", error);
            alert("Failed to submit data. Please try again.");
        }
        console.log(formData); // Just for testing, replace with your actual post request
    };

    return (
        <>
            <NavSub />
            <div className="container mt-4">
                <div className="row  justify-content-center">
                    <div className="col-md-6">
                    <h1 className="text-center mb-4">Add Sub-Admins</h1>
                        <form onSubmit={handleSubmit}>
                        <div className="mb-3">
                                <label htmlFor="Name" className="form-label">Firm Name</label>
                                <input type="text" name="Name" value={formData.Name} onChange={handleChange} className="form-control" id="Name" />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="UserName" className="form-label">Username</label>
                                <input type="text" name="UserName" value={formData.UserName} onChange={handleChange} className="form-control" id="UserName" />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="Password" className="form-label">Password</label>
                                <input type="password" name="Password" value={formData.Password} onChange={handleChange} className="form-control" id="Password" />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="DL" className="form-label">DL</label>
                                <input type="text" name="DL" value={formData.DL} onChange={handleChange} className="form-control" id="DL" />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="GST" className="form-label">GST</label>
                                <input type="text" name="GST" value={formData.GST} onChange={handleChange} className="form-control" id="GST" />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="Email" className="form-label">Email</label>
                                <input type="email" name="Email" value={formData.Email} onChange={handleChange} className="form-control" id="Email" />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="Type" className="form-label">Type</label>
                                <input type="text" name="Type" value={formData.Type} onChange={handleChange} className="form-control" id="Type" />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="place" className="form-label">Place</label>
                                <input type="text" name="place" value={formData.place} onChange={handleChange} className="form-control" id="place" />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="Address" className="form-label">Address</label>
                                <input type="text" name="Address" value={formData.Address} onChange={handleChange} className="form-control" id="Address" />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="Pic" className="form-label">Pic</label>
                                <input type="text" name="Pic" value={formData.Pic} onChange={handleChange} className="form-control" id="Pic" />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="Mobile" className="form-label">Mobile</label>
                                <input type="text" name="Mobile" value={formData.Mobile} onChange={handleChange} className="form-control" id="Mobile" />
                            </div>
                            {/* <div className="mb-3">
                                <label htmlFor="id" className="form-label">ID</label>
                                <input type="text" name="id" value={formData.id} onChange={handleChange} className="form-control" id="id" />
                            </div> */}
                            {/* <div className="mb-3">
                                <label htmlFor="confirmPassword" className="form-label">Confirm Password</label>
                                <input type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} className="form-control" id="confirmPassword" />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="newPassword" className="form-label">New Password</label>
                                <input type="password" name="newPassword" value={formData.newPassword} onChange={handleChange} className="form-control" id="newPassword" />
                            </div> */}
                           
                            {/* Add more input fields for other form data */}
                            <button type="submit" className="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
};

export default ManageProducts;

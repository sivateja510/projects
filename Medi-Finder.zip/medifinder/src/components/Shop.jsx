import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import NavScrollExample from './NavScrollExample';
import medc from '../Assets/medc.jpg';
import Footer from './Footer';
import MuraliKKd from '../Assets/MuraliKKd.jpeg'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCartPlus, faTrash } from '@fortawesome/free-solid-svg-icons'; // Import the trash icon
import { useLocation, useNavigate } from "react-router-dom";
import axios from 'axios';

function Shop() {
    const navigate = useNavigate();
    const location = useLocation();
    const data = location.state;

    const [cart, setCart] = useState([]);
    const [orderr, setorders] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [filteredMedicines, setFilteredMedicines] = useState(data ? data.Tablets : []);

    useEffect(() => {
        const savedCart = JSON.parse(localStorage.getItem('cart')) || [];
        setCart(savedCart);
    }, []);

    useEffect(() => {
        localStorage.setItem('cart', JSON.stringify(cart));
    }, [cart]);

    useEffect(() => {
        const fetchCartData = async () => {
            try {
                const id = JSON.parse(localStorage.getItem("id"));
                const response = await axios.get(`http://localhost:8090/entry/${id}`);
                setCart(response.data.cart);
                // console.log(response.data.cart)
                setorders(response.data.orders)
            } catch (error) {
                console.error("Error fetching cart data:", error);
            }
        };

        fetchCartData();
    }, []);

    const addToCart = (medicine) => {
        const quantity = parseInt(prompt("Enter quantity:", "1"));
        // const so=JSON.parse(localStorage.getItem("Type"))
        // const so=JSON.parse(localStorage.getItem("Type"))
        const so = localStorage.getItem("Type");


        
        if (!isNaN(quantity) && quantity > 0 && so==="User" ) {
            const shopDetails = {
                shopName: data.Name,
                shopAddress: data.Address,
                shopType: data.Type
            };
            const updatedMedicine = { ...medicine, quantity, shopDetails, ShopName: data.Name };
            const updatedCart = [...cart, updatedMedicine];
            setCart(updatedCart);
            postCartData(updatedCart);
        } else {
            alert("Please enter a valid quantity.|| Login and try");
        }
    };

    const removeFromCart = (index) => {
        const updatedCart = [...cart];
        updatedCart.splice(index, 1); // Remove the item at the specified index
        setCart(updatedCart);
        postCartData(updatedCart);
    };

    const postCartData = async (updatedCart) => {
        try {
            const id = JSON.parse(localStorage.getItem("id"));
            await axios.post("http://localhost:8090/entryxyz", { id, updatedCart });
        } catch (error) {
            console.error("Error submitting data:", error);
            alert("Failed to submit data. Please try again.");
        }
    };

    const handleSearch = () => {
        if (data && data.Tablets) {
            const filtered = data.Tablets.filter(medicine =>
                medicine &&
                medicine.medicine &&
                medicine.type &&
                medicine.price &&
                (
                    medicine.medicine.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    medicine.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    medicine.price.toString().includes(searchTerm)
                )
            );
            setFilteredMedicines(filtered);
        }
    };
    
    const id=JSON.parse(localStorage.getItem("id"))
    
    const proceedToCheckout = async () => {
        try {
            const userId = JSON.parse(localStorage.getItem("id"));
            if (!userId) {
                navigate('/login');
                return;
            }
            const comb=[...orderr.items,...cart];
            const order = {
                userId: userId,
                items: comb,
            };

            await axios.post("http://localhost:8090/entryxyzz", { id, order });
            alert("Order placed successfully!");
            setCart([]);
            postCartData([]);
            localStorage.removeItem("cart");
        } catch (error) {
            console.error("Error placing order:", error);
            alert("Failed to place order. Please try again.");
        }
    };

    const clearcart = () => {
        setCart([]);
        localStorage.removeItem('cart');
        postCartData([]); // Post empty cart data
    };

    return (
        <>
            <NavScrollExample />
            <div className="fluid-container">
                <div className='homestart'>
                    <div className="container sms">
                    <div className="row special">
                            <div className="col-md-4 col-sm-6 col-xs-6">
                                <div className="shop-image">
                                    {data&& (
                                    <img src={data.Pic} alt="Medical Shop" className="img-fluid" />
                                    )}
                                    {/* {console.log(data.Pic)} */}
                                    
                                </div>
                            </div>
                            <div className="col-md-8 col-sm-6 col-xs-6">
                                <div className="shop-details">
                                    <h1>{data && data.Name}</h1>
                                    <p><strong>Location:</strong> {data && data.Address}</p>
                                    <p><strong>Type:</strong> {data && data.Type}</p>
                                </div>
                            </div>
                        </div>
                        <div style={{ alignItems: "center", margin: "auto", width: "100%" }}>
                            <div className="search-bar hom">
                                <input
                                    type="text"
                                    placeholder="Search Tablets / Solution / Others.."
                                    value={searchTerm}
                                    onChange={(e) => {
                                        setSearchTerm(e.target.value);
                                        handleSearch();
                                    }}
                                />
                                <button type="button" onClick={handleSearch}>Search</button>
                            </div>
                        </div>
                        <div className="medicines" style={{ maxHeight: "400px", overflowY: "auto" }}>
                            <h2>Available Medicines</h2>
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Type</th>
                                        <th>Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredMedicines&&filteredMedicines.map((medicine, index) => (
                                        <tr key={index}>
                                            <td>{medicine.medicine}</td>
                                            <td>{medicine.type}</td>
                                            <td>{medicine.price}</td>
                                            <td>
                                                <FontAwesomeIcon icon={faCartPlus} onClick={() => addToCart(medicine)} />
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        <div>
                            <h2>Shopping Cart</h2>
                            <div className="row cartng ">
                                <div className="col-md-12">
                                    <div className="row">
                                        {cart&&cart.map((item, index) => (
                                            <div key={index} className="col-md-3 mb-2">
                                                <div className="card">
                                                    <div className="card-body p-2">
                                                        <p className="mb-0">{item.medicine}</p>
                                                        <p>Shop: {item.shopDetails && item.shopDetails.shopName}</p>
                                                        <p>Qty: {item.quantity}</p>
                                                        
                                                        {/* Add delete button */}
                                                        <FontAwesomeIcon
                                                            icon={faTrash}
                                                            onClick={() => removeFromCart(index)}
                                                            style={{ cursor: 'pointer', color: 'red' }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div>
                                    <div className='smxs '>
                                        <button onClick={() => clearcart()} className="btn btn-danger">Clear Cart</button>
                                        <button onClick={proceedToCheckout} className="btn btn-success">Proceed to Checkout</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
}

export default Shop;

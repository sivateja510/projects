import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
import NavScrollExample from './NavScrollExample';
import medc from '../Assets/download.jpeg';
import Footer from './Footer';
import { Card, Button, Modal } from 'react-bootstrap'; // Import Modal from react-bootstrap
import { useLocation } from "react-router-dom";

function Hospital() {
    const location = useLocation();
    const data = location.state;

    // State to manage modal visibility and specialist details
    const [showModal, setShowModal] = useState(false);
    const [selectedSpecialist, setSelectedSpecialist] = useState(null);

    // Function to open modal and set selected specialist details
    const openModal = (specialist) => {
        setSelectedSpecialist(specialist);
        setShowModal(true);
    };

    // Function to close modal
    const closeModal = () => {
        setShowModal(false);
    };

    return (
        <>
            <NavScrollExample />
            <div className="fluid-container">
                <div className='homestart'>
                    <div className="container sms">
                        <div className="row special">
                            <div className="col-md-4 col-sm-6 col-xs-6">
                                <div className="shop-image">
                                    <img src={data.Pic} alt="Medical Shop" className="img-fluid" />
                                </div>
                            </div>
                            <div className="col-md-8 col-sm-6 col-xs-6">
                                <div className="shop-details">
                                    <h1>{data.Name  }</h1>
                                    <p><strong>Location:</strong> {data.Address}</p>
                                    <p><strong>Type:</strong> {data.Type}</p>
                                    <p><strong>Hospital Capacity:</strong> {data.hospital_capacity}</p>
                                    <Button variant="success" > <a href={data.Link}> Hospital Link </a></Button>
                                </div>
                            </div>
                        </div>
                        <div className="medicines">
                            <h2>Available Specialists</h2>
                            <div className="row treatment-list">
                                {data && data.treatments_provided.map((treatment, index) => (
                                    treatment.available === "yes" &&
                                    <div className="col-md-4 mb-4" key={index}>
                                        <Card className="specialist-card" onClick={() => openModal(treatment)}>
                                            <Card.Body className='d-flex justify-content-between'>
                                                <Card.Title>{treatment.name}</Card.Title>
                                                <Button variant="primary">View Details</Button>
                                            </Card.Body>
                                        </Card>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div className="medicines">
                            <h2>Available Generic Treatments</h2>
                            <div className="row treatment-list">
                                {data && data.diseases.map((treatment, index) => (
                                    <div className="col-md-2 mb-4 " key={index}>
                                        <Card className='specialist-card'>
                                            <Card.Body className='d-flex justify-content-between'>
                                                <Card.Title>{treatment.name}</Card.Title>
                                            </Card.Body>
                                        </Card>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal to display specialist details */}
            <Modal show={showModal} onHide={closeModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Specialist Details</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {selectedSpecialist && (
                        <>
                            <p><strong>Name:</strong> {selectedSpecialist.name}</p>
                            <Modal.Body>{selectedSpecialist.description}</Modal.Body>
                            {/* Add more specialist details as needed */}
                        </>
                    )}
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={closeModal}>Close</Button>
                </Modal.Footer>
            </Modal>

            <Footer />
        </>
    );
}

export default Hospital;

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import NavSub from './NavSub';
import { Modal, Button } from 'react-bootstrap';
function NewProductModal(props) {


    const [capsules, setCapsules] = useState([]);
    const [diapers, setDiapers] = useState([]);
    const [drops, setDrops] = useState([]);
    const [tablets, setTablets] = useState([]);
    const [surgicals, setSurgicals] = useState([]);
    const [injections, setInjections] = useState([]);
    const [soaps, setSoaps] = useState([]);
    const [powders, setPowders] = useState([]);
    const [syrups, setSyrups] = useState([]);
    const [ointments, setOintments] = useState([]);
    useEffect(() => {
        fetchData();
    }, []);



    const fetchData = async () => {
        try {
            const response = await axios.get('http://localhost:8090/entrq');
            const data = response.data[0]; // Assuming data is always an array with a single object
            // Set state for each category separately
            setCapsules(data.Capsules || []);
            setDiapers(data.Diapers || []);
            setDrops(data.Drops || []);
            setTablets(data.Tablets || []);
            setSurgicals(data.Surgicals || []);
            setInjections(data.Injections || []);
            setSoaps(data.Soaps || []);
            setPowders(data.Powders || []);
            setSyrups(data.Syrups || []);
            setOintments(data.Ointments || []);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };
    const [formData, setFormData] = useState({
        imageUrl: 'https://via.placeholder.com/150',
        name: '',
        manufacturer: '',
        mrp: 0,
        packing: '',
        price: 0,
        shipper: 0,
        type: ''
    });

    const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData({
            ...formData,
            [id]: value
        });
    };

    const handleSubmit = async () => {

        console.log(formData.type);
        // const { type, ...formData } = formData;
        let combinedData;
        const type=formData.type;
        switch (type) {
            case 'Capsules':
                combinedData = [...capsules, { ...formData }];
                break;
            case 'Diapers':
                combinedData = [...diapers, { ...formData }];
                break;
            case 'Drops':
                combinedData = [...drops, { ...formData }];
                break;
            case 'Surgicals':
                combinedData = [...surgicals, { ...formData }];
                break;
            case 'Ointments':
                combinedData = [...ointments, { ...formData }];
                break;
            case 'Injections':
                combinedData = [...injections, { ...formData }];
                break;
            case 'Soaps':
                combinedData = [...soaps, { ...formData }];
                break;
            case 'Powders':
                combinedData = [...powders, { ...formData }];
                break;
            case 'Syrups':
                combinedData = [...syrups, { ...formData }];
                break;
            
        }
        // const id = JSON.parse(localStorage.getItem("id"));
        console.log(combinedData);
        // try {
        //     // Send POST request to add new product
        //     await axios.post('http://localhost:8090/entrrq', { id, type: formData.type,combinedData });

        //     // Close modal after successful submission
        //     props.onHide();
        //     alert("Product added successfully!");
        // } catch (error) {
        //     console.error('Error adding product:', error);
        //     alert("Failed to add product. Please try again.");
        // }
    }

        return (
            <Modal
                {...props}
                size="md"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Add New Product
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <form>
                        <div className="mb-3">
                            <label htmlFor="name" className="form-label">Product Name</label>
                            <input type="text" className="form-control" id="name" value={formData.name} onChange={handleChange} />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="manufacturer" className="form-label">Manufacturer</label>
                            <input type="text" className="form-control" id="manufacturer" value={formData.manufacturer} onChange={handleChange} />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="mrp" className="form-label">MRP</label>
                            <input type="text" className="form-control" id="mrp" value={formData.mrp} onChange={handleChange} />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="packing" className="form-label">Packing</label>
                            <input type="text" className="form-control" id="packing" value={formData.packing} onChange={handleChange} />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="price" className="form-label">Price</label>
                            <input type="text" className="form-control" id="price" value={formData.price} onChange={handleChange} />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="type" className="form-label">Type</label>
                            <select className="form-control" id="type" value={formData.type} onChange={handleChange}>
                                <option value="Select One">Select one</option>
                                <option value="Capsules">Capsules</option>
                                <option value="Diapers">Diapers</option>
                                <option value="Drops">Drops</option>
                                <option value="Tablets">Tablets</option>
                                <option value="Surgicals">Surgicals</option>
                                <option value="Injections">Injections</option>
                                <option value="Soaps">Soaps</option>
                                <option value="Powders">Powders</option>
                                <option value="Syrups">Syrups</option>
                                <option value="Ointments">Ointments</option>
                            </select>
                        </div>
                        <div className="mb-3">
                            <label htmlFor="shipper" className="form-label">Shipper</label>
                            <input type="text" className="form-control" id="shipper" value={formData.shipper} onChange={handleChange} />
                        </div>
                    </form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" onClick={handleSubmit}>Add Product</Button>
                    <Button variant="secondary" onClick={props.onHide}>Close</Button>
                </Modal.Footer>
            </Modal>
        );
    }


    const Dashboard = () => {
        const [capsules, setCapsules] = useState([]);
        const [diapers, setDiapers] = useState([]);
        const [drops, setDrops] = useState([]);
        const [tablets, setTablets] = useState([]);
        const [surgicals, setSurgicals] = useState([]);
        const [injections, setInjections] = useState([]);
        const [soaps, setSoaps] = useState([]);
        const [powders, setPowders] = useState([]);
        const [syrups, setSyrups] = useState([]);
        const [ointments, setOintments] = useState([]);


        const [categories, setCategories] = useState([]);
        const [selectedCategory, setSelectedCategory] = useState('');
        const [name, setname] = useState('');
        const [manufacturer, setManufacturer] = useState('');
        const [mrp, setMRP] = useState('');
        const [packing, setPacking] = useState('');
        const [price, setPrice] = useState('');
        const [shipper, setShipper] = useState('');
        // const [modalOpen, setModalOpen] = useState(false); // State for modal visibility
        const [modalShow, setModalShow] = useState(false);
        useEffect(() => {
            fetchData();
        }, []);



        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:8090/entrq');
                const data = response.data[0]; // Assuming data is always an array with a single object
                // Set state for each category separately
                setCapsules(data.Capsules || []);
                setDiapers(data.Diapers || []);
                setDrops(data.Drops || []);
                setTablets(data.Tablets || []);
                setSurgicals(data.Surgicals || []);
                setInjections(data.Injections || []);
                setSoaps(data.Soaps || []);
                setPowders(data.Powders || []);
                setSyrups(data.Syrups || []);
                setOintments(data.Ointments || []);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        return (
            <>
                <NavSub />
                <div className="container shop">

                    {/* Render product categories */}
                    <div className="row">
                        {['Capsules', 'Diapers', 'Drops', 'Tablets', 'Surgicals', 'Injections'].map(
                            (category, index) => (
                                <div className="col-lg-4 col-md-6 mb-4" key={index}>
                                    <div className="card">
                                        <div className="card-header">
                                            <h2>{category}</h2>
                                        </div>
                                        <div className="card-body">
                                            <div className="products">
                                                {category === 'Capsules' &&
                                                    capsules.map((product, index) => (
                                                        <div key={index} className="product">
                                                            <p>Name: {product.name}</p>
                                                        </div>
                                                    ))}
                                                {category === 'Diapers' &&
                                                    diapers.map((product, index) => (
                                                        <div key={index} className="product">
                                                            <p>Name: {product.name}</p>
                                                            {/* Render other product details */}
                                                        </div>
                                                    ))}

                                                {category === 'Drops' &&
                                                    drops.map((product, index) => (
                                                        <div key={index} className="product">
                                                            <p>Name: {product.name}</p>
                                                            {/* Render other product details */}
                                                        </div>
                                                    ))}
                                                {category === 'Tablets' &&
                                                    tablets.map((product, index) => (
                                                        <div key={index} className="product">
                                                            <p>Name: {product.name}</p>
                                                            {/* Render other product details */}
                                                        </div>
                                                    ))}
                                                {category === 'Surgicals' &&
                                                    surgicals.map((product, index) => (
                                                        <div key={index} className="product">
                                                            <p>Name: {product.name}</p>
                                                            {/* Render other product details */}
                                                        </div>
                                                    ))}
                                                {category === 'Injections' &&
                                                    injections.map((product, index) => (
                                                        <div key={index} className="product">
                                                            <p>Name: {product.name}</p>
                                                            {/* Render other product details */}
                                                        </div>
                                                    ))}

                                                {/* ... Repeat for Drops, Tablets, etc. */}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        )}

                        {/* Render remaining categories (Soaps, Powders, Syrups, Ointments) */}
                        <div className="col-lg-4 col-md-6 mb-4">
                            <div className="card">
                                <div className="card-header">
                                    <h2>Soaps</h2>
                                </div>
                                <div className="card-body">
                                    <div className="products">
                                        {soaps.map((product, index) => (
                                            <div key={index} className="product">
                                                <p>Name: {product.name}</p>
                                                {/* Render other product details */}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* Render remaining categories (Powders, Syrups, Ointments) */}
                        <div className="col-lg-4 col-md-6 mb-4">
                            <div className="card">
                                <div className="card-header">
                                    <h2>Powders</h2>
                                </div>
                                <div className="card-body">
                                    <div className="products">
                                        {powders.map((product, index) => (
                                            <div key={index} className="product">
                                                <p>Name: {product.name}</p>
                                                {/* Render other product details */}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-lg-4 col-md-6 mb-4">
                            <div className="card">
                                <div className="card-header">
                                    <h2>Syrups</h2>
                                </div>
                                <div className="card-body">
                                    <div className="products">
                                        {syrups.map((product, index) => (
                                            <div key={index} className="product">
                                                <p>Name: {product.name}</p>
                                                {/* Render other product details */}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-lg-4 col-md-6 mb-4">
                            <div className="card">
                                <div className="card-header">
                                    <h2>Ointments</h2>
                                </div>
                                <div className="card-body">
                                    <div className="products">
                                        {ointments.map((product, index) => (
                                            <div key={index} className="product">
                                                <p>Name: {product.name}</p>
                                                {/* Render other product details */}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button onClick={() => setModalShow(true)}>Add Product</button>

                        <NewProductModal
                            show={modalShow}
                            onHide={() => setModalShow(false)}
                        />

                    </div>
                </div>
            </>
        )
    }
    export default Dashboard
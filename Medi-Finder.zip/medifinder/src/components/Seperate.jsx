import React from "react";
import './home.css'
import medi from '../Assets/mediback.jpg';
import img from '../Assets/reactangle.png'
import NavSub from "./NavSub";

function Seperate() {
    return (
        <>
            <NavSub />
            <div className="fluid-container homestart">
            <img src={img} alt='image' className="imag" />
                <div className="home">
                    <div className="container py-2   cont1">
                        <div className="row justify-content-center">
                            <div className="col-lg-11 col-md-10 col-sm-12">
                                <p className="labell">Hospitals</p>
                            </div>
                        </div>
                        <div className="row justify-content-around">
                            <div className="col-lg-3 col-md-6 col-sm-12 mb-4">
                                <img src={medi} className="img-thumbnail" alt="Hospital Thumbnail" />
                            </div>
                            <div className="col-lg-3 col-md-6 col-sm-12 mb-4">
                                <h6 className="labell">Name</h6>
                                <p>Hospital Name Here</p>
                                <ul>
                                    <li>some text</li>
                                    <li>some text</li>
                                    <li>some text</li>
                                </ul>
                            </div>
                            <div className="col-lg-3 col-md-12 col-sm-12 mb-12">
                                <p className="labell">Location</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                    ut labore et dolore magna aliqua.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className="container py-5 cont2">
                        {/* Additional content for cont2 */}
                    </div>
                </div>
            </div>
        </>
    )
}

export default Seperate;

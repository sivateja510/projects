import React from 'react';
import { Container, Nav, Navbar } from 'react-bootstrap';
import { Link } from 'react-router-dom';

function NavScrollExample() {
  const Typ = localStorage.getItem("Type");

  const handleLogout = () => {
    // Perform logout action here, such as clearing local storage, redirecting, etc.
    localStorage.removeItem("Type");
    // You may also want to redirect the user to the login page or any other appropriate action.
  };

  return (
    <Navbar collapseOnSelect expand="lg" className="bg-body-tertiary">
      <Container>
        <Navbar.Brand href="#home">MediFinder</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">

          </Nav>
          <Nav>
            <Nav.Link href="/">Home</Nav.Link>
            {Typ === "User" ? (
              <>
              
              <Nav.Link href="/Ucart">Cart</Nav.Link>
              <Nav.Link onClick={handleLogout} href="/">Logout</Nav.Link>
              </>
            ) : (
              <Nav.Link href="/login">Login</Nav.Link>
             
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default NavScrollExample;

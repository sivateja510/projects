
import { useEffect, useState } from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import Footer from './Footer';
import img from '../Assets/signupimg.jpg';
import React from 'react';
import Modal from 'react-bootstrap/Modal';
import './mediaque.css'
import NavScrollExample from './NavScrollExample';
import axios from 'axios';
function NewPasswordModal(props) {
    const [Password, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const Type="User"
    const handleNewPasswordChange = (event) => {
        const value = event.target.value;
        setNewPassword(value);
        setPasswordData(prevData => ({
            ...props.formd,
            Type:Type,
            Password: value
        }));
    };
    
    const handleConfirmPasswordChange = (event) => {
        const value = event.target.value;
        setConfirmPassword(value);
    };
    
    const [passwordData, setPasswordData] = useState({
        Password: '',
        Type: 'User',
        Name: '',
        mobile: '',
        Email: '',
        cart:[],
        orders:{},
        place:"Kakinada"
    });
    

    

    const handleSubmit =async () => {
        // Validate passwords
        if (Password !== confirmPassword) {
            alert("Passwords do not match");
            return;
        }

        if (Password.length < 8) {
            alert("Password must be at least 8 characters long");
            return;
        }
        try {
            await axios.post("http://localhost:8090/entryin", passwordData);
            alert("Data submitted successfully");
        } catch (error) {
            console.error("Error submitting data:", error);
            alert("Failed to submit data. Please try again.");
        }

        // You can proceed with the submission here
        console.log(passwordData);
    };

    return (
        <Modal
            {...props}
            size="md"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header closeButton>
                <Modal.Title id="contained-modal-title-vcenter">
                    Set Up Password
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <form>
                    <div className="mb-3">
                        <label htmlFor="newPassword" className="form-label">Enter new Password</label>
                        <input type="password" className="form-control" id="Password" maxLength="16" value={Password} onChange={handleNewPasswordChange} />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="confirmPassword" className="form-label">Confirm Password</label>
                        <input type="password" className="form-control" id="confirmPassword" maxLength="16" value={confirmPassword} onChange={handleConfirmPasswordChange} />
                    </div>
                </form>
                <h4>Instructions:</h4>
                <p>
                    Please enter your new password below. Your new password must be at least 8 characters long and contain a combination of letters, numbers, and special characters.
                </p>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="primary" onClick={handleSubmit}>Submit</Button>
            </Modal.Footer>
        </Modal>
    );
}

function Signup() {

    const [secondModalShow, setSecondModalShow] = useState(false);
    const [newPasswordModalShow, setNewPasswordModalShow] = useState(false);


    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [formData, setFormData] = useState({
        Name: '',
        mobile: '',
        Email: ''
    });

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormData({ ...formData, [name]: value });
    };


   

    const handleSubmit = (event) => {
        // console.log(formData)
        // setSecondModalShow(true);

        setNewPasswordModalShow(true);
        event.preventDefault();
    };

    return (
        <>
            <NavScrollExample />
            <Container className='my-5'>
                <Row className='justify-content-center gap-2'>
                    <Col lg={6} md={10} className='d-none d-sm-none d-md-none d-lg-block'>
                        <img src={img} alt="shdsvh" className='img-fluid h-100 rounded' /></Col>
                    <Col lg={{ span: 4, offset: 1 }} md={12} sm={12} style={{ flex: 1, paddingTop: '20px' }}>

                        <div className="d-flex flex-column justify-content-center align-items-center addonsmsignup" >
                            <div className='w-100'>
                                <h3 class="text-center mb-4">SignUp</h3>
                                <h1>{secondModalShow}</h1>
                                <form onSubmit={handleSubmit}>
                                    <div className="form-group mb-4 d-flex flex-column align-items-start gap-2 w-80">
                                        <label htmlFor="name">Name:</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="name"
                                            name="Name"
                                            placeholder="Enter here"
                                            value={formData.name}
                                            onChange={handleInputChange}
                                        />
                                    </div>
                                    <div className="form-group mb-4 d-flex flex-column align-items-start gap-2">
                                        <label htmlFor="mobile">Mobile Number:</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="mobile"
                                            name="mobile"
                                            placeholder="Enter here"
                                            value={formData.mobile}
                                            onChange={handleInputChange}
                                        />
                                    </div>
                                    <div className="form-group mb-4 d-flex flex-column align-items-start gap-2">
                                        <label htmlFor="email">Email:</label>
                                        <input
                                            type="email"
                                            className="form-control"
                                            id="email"
                                            name="Email"
                                            placeholder="Enter here"
                                            value={formData.Email}
                                            onChange={handleInputChange}
                                        />
                                    </div>
                                    <div className="form-group d-flex justify-content-center mt-5">
                                        <button type="submit" className="btn btn-primary btn-lg mx-auto w-50 rounded-pill">Next</button>
                                    </div>
                                </form>
                                <NewPasswordModal
                                    show={newPasswordModalShow}
                                    onHide={() => setNewPasswordModalShow(false)}
                                    onSubmit={() => {
                                        // Logic for handling new password submission goes here
                                        // For example, you can send the new password to your server
                                        // and handle any necessary validation or processing
                                        console.log('New password submitted');
                                        setNewPasswordModalShow(false);
                                    }}
                                    formd={formData}

                                />
                            </div>

                        </div>
                    </Col>
                </Row>
            </Container>
            <Footer />
        </>
    );
}

export default Signup;
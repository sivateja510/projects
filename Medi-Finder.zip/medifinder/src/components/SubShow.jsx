import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { Modal, Button } from 'react-bootstrap';
import { FaPlus } from "react-icons/fa";
import img from '../Assets/reactangle.png';
import med from '../Assets/meds.png';
import NavSub from "./NavSub";
import './SubShow.css';

const SubShow = () => {
    const [medicineType, setMedicineType] = useState("");
    const [medicineData, setMedicineData] = useState([]);
    const [selectedMedicine, setSelectedMedicine] = useState(null);
    const [quantity, setQuantity] = useState(1);
    const [showModal, setShowModal] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");
    const [filteredMedicine, setFilteredMedicine] = useState([]);
    // const cartRef = useRef([]);

    useEffect(() => {
        getMedicine();
    }, []);

    useEffect(() => {
        filterMedicine();
    }, [searchQuery, selectedMedicine]);

    const getMedicine = async () => {
        try {
            const response = await axios.get('http://localhost:8090/entryA');
            setMedicineData(response.data[0]);
            const typee = localStorage.getItem("type");
            setSelectedMedicine(response.data[0][typee]);
            cartRef.current = []; // Clear the cart reference when new data is fetched
        } catch (error) {
            console.error(error);
        }
    }

    const filterMedicine = () => {
        if (selectedMedicine && selectedMedicine.length > 0) {
            let filtered = selectedMedicine.filter(medicine =>
                Object.values(medicine).some(value =>
                    typeof value === "string" && value.toLowerCase().includes(searchQuery.toLowerCase())
                )
            );
            setFilteredMedicine(filtered);
        }
    }

    const [cartItems, setCartItems] = useState([]);
    const cartRef = useRef(cartItems);
    const handleAddToCart = () => {
        console.log("Adding to cart:", selectedMedicine, "Quantity:", quantity);
        const existingCartItems = JSON.parse(localStorage.getItem("order")) || [];
        const item = { ...selectedMedicine, quantity };
        const updatedCart = [...existingCartItems, item];
        setCartItems(updatedCart);
        localStorage.setItem("order", JSON.stringify(updatedCart));
        setShowModal(false);
        if(existingCartItems)
        {
            window.alert("Cart is Updated with new Quantity")
        }
        else{
            window.alert("Product added to cart")
        }
        
    };

    const openModal = (medicine) => {
        setSelectedMedicine(medicine);
        setShowModal(true);
    };

    const closeModal = () => {
        setShowModal(false);
    };

    return (
        <>
            <NavSub />
            <div className="fluid-container homestart">
                <img src={img} alt='image' className="imag" />
                <div className="homes">
                    <div className="homee">
                        <input
                            type="text"
                            placeholder="Search Tablets / Solution / Others.."
                            style={{ width: "40%", height: "40px" }}
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                        <button>Search</button>
                        
                    </div>
                    

                    <div className="container home1 py-4 px-5">
                        <div className="row justify-content-center align-items-stretch gap-3">
                            {filteredMedicine && filteredMedicine.map((medicine, index) => (
                                <div key={index} className="card subcard py-3 col-md-3 col-sm-6 col-xs-12" style={{ width: "16rem" }}>
                                    <img className="card-img-top border border-dark" src="https://t4.ftcdn.net/jpg/02/76/80/31/240_F_276803150_yUZGcTLjJErZdmLw0GhDzARQY91S6yrv.jpg" alt="Card image cap" style={{ width: "50%", margin: "auto" }} />
                                    <div className="card-body">
                                        <h6 className="card-title text-primary text-center">{medicine.name}</h6>
                                        <p className="card-text">{medicine.manufacturer}</p>
                                        <div className="d-flex justify-content-between">
                                            <p style={{ fontWeight: "700" }}>Mrp: Rs&nbsp;{medicine.mrp}</p>
                                            <p>Packing: {medicine.packing}</p>
                                        </div>
                                        <div className="d-flex justify-content-between">
                                            <p style={{ fontWeight: "700" }}>Price: Rs&nbsp;{medicine.price}</p>
                                            <p>Shipper: {medicine.shipper}</p>
                                        </div>
                                        <h6 style={{ textDecoration: "none", cursor: "pointer" }} className="text-center border border-dark rounded-pill py-1" onClick={() => openModal(medicine)}>Add <FaPlus className="text-primary text-center" /></h6>
                                    </div>
                                </div>
                            ))}
                            
                        </div>
                        

                    </div>
                    
                </div>
                
            </div>
            <Modal show={showModal} onHide={closeModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Add to Cart</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <p>{selectedMedicine && selectedMedicine.name}</p>
                    <label>Quantity:</label>
                    <input type="number" min="1" value={quantity} onChange={(e) => setQuantity(parseInt(e.target.value))} />
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={closeModal}>Cancel</Button>
                    <Button variant="primary" onClick={handleAddToCart}>Add to Cart</Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}

export default SubShow;

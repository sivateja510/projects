import { useState, useEffect, useContext } from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import NavScrollExample from './NavScrollExample';
import Footer from './Footer';
import img from '../Assets/imgg.png';
import React from 'react';
import './mediaque.css'
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import Modal from 'react-bootstrap/Modal';
import { Context } from './Context';

function MyVerticallyCenteredModal(props) {

    return (
        <Modal
            {...props}
            size="sm"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header closeButton>
                <Modal.Title id="contained-modal-title-vcenter">
                    Forgot Password
                </Modal.Title>
            </Modal.Header>
            <Modal.Body >
                <form>
                    <div class="mb-3">
                        <label for="otpInput" class="form-label">Enter Mobile Number</label>
                        <input type="text" class="form-control" id="otpInput" maxlength="6" placeholder=" Eg:+91 1234567899  " />
                    </div>
                </form>
            </Modal.Body>
            <Modal.Footer>
                <Button onClick={props.onHide}>Submit</Button>
            </Modal.Footer>
        </Modal>

    );
}
function NewPasswordModal(props) {
    return (
        <Modal
            {...props}
            size="md"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header closeButton>
                <Modal.Title id="contained-modal-title-vcenter">
                    Set up Password
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <form>
                    <div class="mb-3">
                        <label for="otpInput" class="form-label">Enter new Password</label>
                        <input type="password" class="form-control" id="otpInput" maxlength="6" />
                    </div>
                    <div class="mb-3">
                        <label for="otpInput" class="form-label">confirm Password</label>
                        <input type="password" class="form-control" id="otpInput" maxlength="6" />
                    </div>
                </form>
                <h4>Instructions:</h4>
                <p>
                    Please enter your new password below. Your new password must be at least 8 characters long and contain a combination of letters, numbers, and special characters.
                </p>
                {/* Your form elements for entering the new password go here */}
            </Modal.Body>
            <Modal.Footer>
                {/* <Button onClick={props.onHide}>Close</Button> */}
                <Button variant="primary" onClick={props.onSubmit}>Submit</Button>
            </Modal.Footer>
        </Modal>
    );
}

function Login() {
    const [modalShow, setModalShow] = useState(false);
    const [secondModalShow, setSecondModalShow] = useState(false);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [users, setUsers] = useState();
    const navigate = useNavigate();
    const { items, setItems } = useContext(Context);

    useEffect(() => {
        localStorage.clear();
        getUsers();
    },[]);

    const getUsers = async () => {
        try {
            const response = await axios.get('http://localhost:8090/entry');
            setUsers(response.data);
            // console.log(users);
        } catch (error) {
            console.error(error);
        }
    }
    

    const handleUsernameChange = (event) => {
        setUsername(event.target.value);
    };

    const handlePasswordChange = (event) => {
        setPassword(event.target.value);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        console.log(users);
        const userExists = users.some(user => user.Email === username);
        if (!userExists) {
            alert('Invalid username.');
            return;
        }
        const user = users.find(user => user.Email === username);
        if (user.Password !== password) {
            alert(user.Password)
            alert('Invalid password.');

            return;
        }
        else {
            console.log('Username:', username);
            console.log('Password:', password);
            setItems(user);
            window.alert("Logged In");

            localStorage.setItem("id",JSON.stringify(user._id));
            localStorage.setItem("usname",JSON.stringify(user.Name));
            localStorage.setItem("Data",JSON.stringify(user))
            alert(user.Type)
        }
        switch (user.Type) {
            case 'Shop':
                navigateToHomePageForAdmin();
                break;
            case 'User':
                navigateToSubHomePageForRegularUser();
                break;
            case 'Admin':
                Admin();
                break;
        }
    };
    
    const navigateToHomePageForAdmin = () => {
        localStorage.setItem("Type","Shop");
        navigate('/SubHome');
    };

    const navigateToSubHomePageForRegularUser = () => {
        localStorage.setItem("Type","User");
        navigate('/');
    };
    const Admin = () => {
        localStorage.setItem("Type","Admin");
        navigate('/AdminDashboard');
    };


    const handleCloseFirstModal = () => {
        setModalShow(false);
        setSecondModalShow(true);
    };

    const model = () => {
        setSecondModalShow(false);
        setModalShow(true);
    };


    return (
        <>
            <NavScrollExample />
            <Container className='my-5'>
                <Row className='justify-content-center gap-2'>
                    <Col lg={6} md={10} className='d-none d-sm-none d-md-none d-lg-block'>
                        <img src={img} alt="shdsvh" className='img-fluid h-100' />
                    </Col>
                    <Col lg={{ span: 4, offset: 1 }} md={12} sm={12} style={{ flex: 1, paddingTop: '20px' }}>
                        <div className="d-flex flex-column justify-content-center align-items-center addonsm" >
                            <div className='w-100'>
                                <h3 className="text-center mb-4">Login</h3>
                                <form onSubmit={handleSubmit}>
                                    <div className="form-group mb-4 d-flex flex-column align-items-start gap-2 w-80">
                                        <label htmlFor="email">Email ID:</label>
                                        <input type="email" className="form-control" id="email" placeholder="Enter here" onChange={handleUsernameChange} />
                                    </div>
                                    <div className="form-group mb-4 d-flex flex-column align-items-start gap-2">
                                        <label htmlFor="password">Password:</label>
                                        <input type="password" className="form-control" id="password" placeholder="Enter here" onChange={handlePasswordChange} />
                                    </div>
                                    <div className="form-group mb-4 d-flex justify-content-end">
                                        <a href="#" className="text-danger fw-bold" style={{ textDecoration: "none" }} onClick={() => setModalShow(true)}>Forgot password?</a>
                                    </div>
                                    <Modal show={modalShow} onHide={() => setModalShow(false)}>
                                        <Modal.Header closeButton>
                                            <Modal.Title>Forgot Password</Modal.Title>
                                        </Modal.Header>
                                        <Modal.Body>
                                            <form>
                                                <div className="mb-3">
                                                    <label htmlFor="otpInput" className="form-label">Enter Mobile Number</label>
                                                    <input type="text" className="form-control" id="otpInput" maxLength="10" placeholder="Eg: +91 1234567899" />
                                                </div>
                                            </form>
                                        </Modal.Body>
                                        <Modal.Footer>
                                            <Button onClick={handleCloseFirstModal}>Submit</Button>
                                        </Modal.Footer>
                                    </Modal>
                                    <Modal show={secondModalShow} onHide={() => setSecondModalShow(false)}>
                                        <Modal.Header closeButton>
                                            <Modal.Title>Verify OTP</Modal.Title>
                                        </Modal.Header>
                                        <Modal.Body>
                                            <p>A verification code has been sent to your phone number. Please enter the code below to continue.</p>
                                            <form>
                                                <div className="mb-3">
                                                    <label htmlFor="otpInput" className="form-label">Verification Code</label>
                                                    <input type="text" className="form-control" id="otpInput" maxLength="6" placeholder="Enter 6-digit code" />
                                                </div>
                                                
                                            </form>
                                            <p className="mt-3 text-muted">Didn't receive the code? <a href="#">Request a new code</a></p>
                                       
                                        </Modal.Body>
                                        <Modal.Footer>
                                            <Button onClick={model}>Verify</Button>
                                        </Modal.Footer>
                                    </Modal>
                                    <NewPasswordModal /> {/* Render the NewPasswordModal component here */}
                                    <div className="form-group d-flex justify-content-center">
                                        <button type="submit" className="btn btn-primary btn-lg mx-auto w-50 rounded-pill">Login</button>
                                    </div>
                                    {/* <div className="text-center my-2">
                                        <p>Or Login with</p>
                                        <button type="button" className="btn btn-outline-primary mx-3">Gmail</button>
                                        <button type="button" className="btn btn-outline-primary">Mobile</button>
                                    </div> */}
                                     
                                    <div className="text-center mt-3">
                                        <p>Don't have an account? <Link to='/signup' style={{ textDecoration: "none" }}>Signup</Link></p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
            <Footer />
        </>
    );
}

export default Login;

import { useState } from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import NavScrollExample from './NavScrollExample';
import Footer from './Footer';
import img from '../Assets/imgg.png';
function LoginForgot() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleUsernameChange = (event) => {
        setUsername(event.target.value);
    };

    const handlePasswordChange = (event) => {
        setPassword(event.target.value);
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        // Here you can handle form submission, e.g., sending data to a server
        console.log('Username:', username);
        console.log('Password:', password);
    };

    return (
        <>
            <NavScrollExample />
            <Container className='my-5'>
                <Row className='justify-content-center gap-2'>
                    <Col lg={6} md={10}  >
                        <img src={img} alt="shdsvh" className='img-fluid h-100'/></Col>
                    <Col lg={{ span: 4, offset: 1 }} md={10} style={{ flex: 1, paddingTop: '20px' }}>
                        <div className="d-flex flex-column justify-content-center align-items-center">
                            <div className='w-100'>
                                <h3 class="text-left mb-4">Login</h3>
                                <form>
                                    <div class="form-group mb-4 d-flex flex-column align-items-start gap-2 w-80">
                                        <label for="email">Email ID:</label>
                                        <input type="email" class="form-control" id="email" placeholder="Enter here" />
                                    </div>
                                    <div class="form-group mb-4 d-flex flex-column align-items-start gap-2">
                                        <label for="password">Password:</label>
                                        <input type="password" class="form-control" id="password" placeholder="Enter here" />
                                    </div>
                                    <div class="form-group mb-4 d-flex justify-content-end">
                                        <a href="#" className="text-danger fw-bold" style={{textDecoration:"none"}} onClick={() => setModalShow(true)}>Forgot password?</a>
                                    </div>
                                    <div class="form-group d-flex justify-content-center">
                                        <button type="submit" class="btn btn-primary btn-lg mx-auto w-50 rounded-pill">Login</button>
                                    </div>
                                    <div class="text-center my-2">
                                        <p>Or Login with</p>
                                        <button type="button" class="btn btn-outline-primary mx-3">Gmail</button>
                                        <button type="button" class="btn btn-outline-primary">Mobile</button>
                                    </div>
                                    <div class="text-center mt-3">
                                        <p>Don't have an account? <a href="#" style={{textDecoration:"none"}}>Signup</a></p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
            <Footer />
        </>
    );
}

export default LoginForgot;

import React, { useState, useEffect } from "react";
import NavSub from "./NavSub";
import axios from "axios";

const ManageSubAdmins = () => {
    const [shops, setShops] = useState([]);

    useEffect(() => {
        getShops();
    }, []);

    const getShops = async () => {
        try {
            const response = await axios.get('http://localhost:8090/entry');
            setShops(response.data);
        } catch (error) {
            console.error(error);
        }
    };

    const deleteShop = async (id) => {
        try {
            await axios.delete(`http://localhost:8090/entry/${id}`);
            // After deletion, fetch the updated list of shops
            getShops();
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <>
            <NavSub />
            <div className="container mt-4">
                <div className="row">
                    {shops.map(shop => {
                        // Check if the current item is a shop
                        if (shop.Type === 'Shop' && shop !== null) {
                            return (
                                <div key={shop._id} className="col-lg-4 col-md-6 mb-4">
                                    <div className="card">
                                        <div className="card-body">
                                            <h5 className="card-title">{shop.Name}</h5>
                                            <p className="card-text">Place: {shop.place}</p>
                                            <p className="card-text">Address: {shop.Address}</p>
                                            {/* Render more shop details if needed */}
                                            <button className="btn btn-danger" onClick={() => deleteShop(shop._id)}>Delete</button>
                                        </div>
                                    </div>
                                </div>
                            );
                        } else {
                            
                            return null; // For example, rendering nothing in case it's not a shop
                        }
                    })}

                </div>
            </div>
        </>
    );
};

export default ManageSubAdmins;

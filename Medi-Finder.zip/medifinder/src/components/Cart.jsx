import React from "react";
import NavSub from "./NavSub";
import Footer from "./Footer";
import img from '../Assets/reactangle.png';
import { useState, useEffect } from "react";
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import Modal from 'react-bootstrap/Modal';
import { Link, useNavigate } from 'react-router-dom';
import axios from "axios";
function NewPasswordModal(props) {
    return (
        <Modal
            {...props}
            size="md"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header closeButton>
                <Modal.Title id="contained-modal-title-vcenter">
                    Set up Password
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <form>
                    <div class="mb-3">
                        <label for="otpInput" class="form-label">Enter new Password</label>
                        <input type="password" class="form-control" id="otpInput" maxlength="6" />
                    </div>
                    <div class="mb-3">
                        <label for="otpInput" class="form-label">confirm Password</label>
                        <input type="password" class="form-control" id="otpInput" maxlength="6" />
                    </div>
                </form>
                <h4>Instructions:</h4>
                <p>
                    Please enter your new password below. Your new password must be at least 8 characters long and contain a combination of letters, numbers, and special characters.
                </p>
                {/* Your form elements for entering the new password go here */}
            </Modal.Body>
            <Modal.Footer>
                {/* <Button onClick={props.onHide}>Close</Button> */}
                <Button variant="primary" onClick={props.onSubmit}>Submit</Button>
            </Modal.Footer>
        </Modal>
    );
}

function MyVerticallyCenteredModall(props) {
    const { data, ...rest } = props;

    return (
        <Modal
            {...rest}
            size="smx"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header closeButton>
                <Modal.Title id="contained-modal-title-vcenter">
                    Order details
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                {data ? (
                    <>
                        {/* Render your order details here */}
                        <p>
                            <b>Firm Name:</b> {data.name}<br />
                            <b>Order Date:</b> {data.date}
                        </p>
                        <hr />
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                </tr>
                            </thead>
                            <tbody>
                                {/* Render order details here */}
                                {data && data.OrderDetails.map((order, index) => (
                                    <tr key={index}>
                                        <td>{order.name}</td>
                                        <td>{order.quantity}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        <hr />
                        <h3>Delivery Address</h3>
                        {/* Render delivery address here */}
                        <p>{data.Address}</p>
                        <hr />
                        {/* Render order status here */}
                        <p>
                            <b>Status:</b> order will deliver shortly
                        </p>
                    </>
                ) : (
                    <p>No data available</p>
                )}
            </Modal.Body>
        </Modal>
    );
}

function CartModal(props) {
    function getDataFromLocalStorage(key) {
        const data = localStorage.getItem(key);
        if (data) {
            try {
                return JSON.parse(data);
            } catch (error) {
                console.error("Error parsing localStorage data:", error);
                return null;
            }
        } else {
            console.error("No data found in localStorage for key:", key);
            return null;
        }
    }
    useEffect(() => {
        getUser();
    }, []);
    const [user, setUser] = useState([]);
    const getUser = async () => {
        try {
            console.log(id);
            const response = await axios.get(`http://localhost:8090/entry/${id}`);
            setUser(response.data);
            console.log(response.data);
            // setTabletDetails(user.Tablets);

        } catch (error) {
            console.error("Error fetching user data:", error);
        }
    };


    const cartItems = getDataFromLocalStorage("order");

    const id = JSON.parse(localStorage.getItem("id"));
    const handleSubmitr = async () => {

        const bef = user.orders||[];
        const data = [{ "name": user.UserName, "date": "1-20-3024", "Address": user.Address, "OrderDetails": cartItems }]
        const cartItem = [...bef, ...data];
        try {
            // const ids = id._id;
            await axios.post("http://localhost:8090/entryxy", { id, cartItem });
            // setTableData([]);
            alert("Data submitted successfully");
        } catch (error) {
            console.error("Error submitting data:", error);
            alert("Failed to submit data. Please try again.");
        }
        localStorage.setItem("order", JSON.stringify([]));
        window.alert("order Placed Sucessfully")
        window.location.reload();
    };
    
    

    return (
        <Modal
            {...props}
            size="smx"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header closeButton>
                <Modal.Title id="contained-modal-title-vcenter">
                    Cart Items
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div className="table-responsive">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            {cartItems && cartItems.length > 0 ? (
                                cartItems.map((item, index) => (
                                    <tr key={index}>
                                        <td>{item.name}</td>
                                        <td>{item.quantity}</td> {/* Assuming each item has a quantity of 1 */}
                                        <td>{item.quantity * item.mrp}</td> {/* Assuming each item has a quantity of 1 */}
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan="2">No items in the cart</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Modal.Body>
            <Modal.Footer>
                <button className="btn btn-primary" onClick={() => handleSubmitr()}>
                    Place Order
                </button>
            </Modal.Footer>
        </Modal>
    );
}



const Cart = () => {
    const navigate = useNavigate();
    const [modalShown, setModalShownx] = useState(false);
    const handleCloseFirstModall = () => {
        setModalShownx(false);
    };
    const [modalShownn, setModalShownn] = useState(false);
    const handleCloseFirstModal = () => {
        setModalShownn(false);
    };

    const [selectedItem, setSelectedItem] = useState('');
    // Function to store item in local storage
    const storeItem = (item) => {
        localStorage.setItem('type', item);
        navigate('/SubShow');
        setSelectedItem(item);
    };
    const [selectedOrder, setSelectedOrder] = useState(null);
    const shoiwn = () => {
        const dat = JSON.parse(localStorage.getItem("order"))
        // window.alert(dat);
        setModalShownn(true);
        console.log(dat);
    }
    const shoiwnk = (order) => {
        // alert("1234")
        setSelectedOrder(order);
        setModalShownx(true);
        console.log(order);

    }
    const [meds, setmeds] = useState();
    useEffect(() => {
        // Retrieve stored item from local storage if exists
        const storedItem = localStorage.getItem('selectedItem');
        setmeds(localStorage.getItem('order'));
        if (storedItem) {
            setSelectedItem(storedItem);
        }
    }, []);


    useEffect(() => {
        const storedCartItems = JSON.parse(localStorage.getItem('order')) || [];
        setCartItems(storedCartItems);
        postCartData(storedCartItems);
    }, []);

    const postCartData = async (updatedCart) => {
        try {
            console.log(updatedCart)

            const id = JSON.parse(localStorage.getItem("id"));
            await axios.post("http://localhost:8090/entryxyz", { id, updatedCart });
            // alert("Data submitted successfully");
        } catch (error) {
            console.error("Error submitting data:", error);
            alert("Failed to submit data. Please try again.");
        }
    };
    const gridData = [
        { title: 'Capsules', image: '/group-454.svg' },
        { title: 'Diapers', image: '/group-445.svg' },
        { title: 'Drops', image: '/group-446.svg' },
        { title: 'Tablets', image: '/group-447.svg' },
        { title: 'Surgicals', image: '/group-451.svg' },
        { title: 'Injections', image: '/group-454.svg' },
        { title: 'Soaps', image: '/group-445.svg' },
        { title: 'Powders', image: '/group-446.svg' },
        { title: 'Syrups', image: '/group-447.svg' },
        { title: 'Ointments', image: '/group-451.svg' },
    ];
    const [showModal, setShowModal] = useState(false);
    const [cartItems, setCartItems] = useState([]);
    useEffect(() => {
        getUser();
    }, []);
    const id = JSON.parse(localStorage.getItem("id"));
    const [user, setUser] = useState([]);
    const getUser = async () => {
        try {
            console.log(id);
            const response = await axios.get(`http://localhost:8090/entry/${id}`);
            setUser(response.data);
            console.log(response.data);
            // setTabletDetails(user.Tablets);

        } catch (error) {
            console.error("Error fetching user data:", error);
        }
    };
    

    return (
        <>
            <NavSub />
            <div className="fluid-container homestart">
                <img src={img} alt='image' className="imag" />
                <div className="home">
                    <div className="container py-4 cont1">
                        <div class="row justify-content-between mx-2 py-2">
                            <div class="col-auto">
                                <strong>Categories</strong>
                            </div>
                            <div class="col-auto">
                                {/* <strong style={{ color: 'blue' }}>View Details</strong> */}
                            </div>
                        </div>

                        <div className="row justify-content-around align-items-center mx-2">
                            <section className="grid-section">
                                <div className="grid-container">
                                    <div className="grid-item">
                                        {gridData.map((item, index) => (
                                            <div key={index} className="grid-sub-item" onClick={() => storeItem(item.title)}>
                                                {/* <img className="grid-sub-item-img" loading="eager" alt="" src={item.image} /> */}
                                                <div className="grid-sub-item-title">{item.title}</div>
                                                {/* <div class="grid-sub-item-title">Soaps</div> */}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </section>
                        </div>

                    </div>

                    <div className="container py-4 cont3">
                        <h5 className="mb-4">Cart Items Ready to Place Order</h5>
                        {cartItems.length === 0 ? (

                            <div className="cart">
                                <p>Your cart is empty.</p>
                            </div>
                        ) : (
                            <div className="cart">
                                {/* <button className="btn btn-primary" onClick={()=>setModalShown(true)}>View Cart Items</button> */}
                                <p>Number of items in cart: {cartItems.length}</p>
                                <button className="btn btn-primary" onClick={() => shoiwn()}>View Cart Items</button>
                            </div>
                        )}
                    </div>


                    <div class="container py-4 cont3">
                        <div>
                            <h5 className="mb-4">Order History</h5>
                            {user.orders && user.orders.length > 0 ? (
                                user.orders.map((order, index) => (
                                    <div key={index} className="cart">
                                        <div>
                                            <div style={{ color: "gray" }}>Order Date</div>
                                            <div>{order.date}</div> {/* Assuming order.date contains the order date */}
                                        </div>
                                        <div className="hidd">
                                            <div style={{ color: "gray" }}>No oF Items</div>
                                            <div>{order.OrderDetails.length}</div> {/* Assuming order_txns contains transaction information */}
                                        </div>
                                        <div className="onest">
                                            <div style={{ color: "black", fontSize: "15px" }}>Order Details</div>
                                            <div style={{ color: "blue" }} onClick={() => shoiwnk(order)}>View</div>
                                        </div>

                                    </div>

                                ))
                            ) : (
                                <div>No orders found</div>
                            )}
                        </div>
                        <MyVerticallyCenteredModall
                            show={modalShown}
                            onHide={() => handleCloseFirstModall(true)}
                            data={selectedOrder}
                        />
                        <CartModal
                            show={modalShownn}
                            onHide={() => handleCloseFirstModal(true)}
                        />
                    </div>
                    <Footer />
                </div>
            </div>
        </>
    )
}
export default Cart;
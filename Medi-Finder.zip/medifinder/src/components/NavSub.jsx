import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Link } from 'react-router-dom';

function NavSub() {
  const Typ = localStorage.getItem("Type");
  const handleLogout = () => {
    // Perform logout action here, such as clearing local storage, redirecting, etc.
    localStorage.removeItem("Type");
    // You may also want to redirect the user to the login page or any other appropriate action.
  };

  return (
    <Navbar collapseOnSelect expand="lg" className="bg-body-tertiary">
      <Container>
        <Navbar.Brand href="#home">MediFinder</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">

          </Nav>
          <Nav>


            {Typ === "Shop" ? (
              <>
                <Nav.Link href="SubHome">Home</Nav.Link>
                <Nav.Link href="SubAdd">Add</Nav.Link>
                <Nav.Link href="Cart">Cart</Nav.Link>
                <Nav.Link href="Collect">Orders</Nav.Link>
                <Nav.Link href="Sell">Sell</Nav.Link>
                <Nav.Link onClick={handleLogout} href="/Login">LogOut</Nav.Link>
              </>
            ) : Typ === "Admin" ? (
              <>
                <Nav.Link href="AdminDashboard">Dashboard</Nav.Link>
                <Nav.Link href="ManageUsers">Manage Users</Nav.Link>
                <Nav.Link href="ManageProducts">AddShops</Nav.Link>
                <Nav.Link onClick={handleLogout} href="/Login">LogOut</Nav.Link>
              </>
            ) : (
              <Nav.Link href="/login">Login</Nav.Link>
            )}


          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default NavSub;
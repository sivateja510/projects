
import { useState } from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import NavScrollExample from './NavScrollExample';
import Footer from './Footer';
import img from '../Assets/signup.jpg';
import React from 'react';
import Modal from 'react-bootstrap/Modal';
import './mediaque.css'


function NewPasswordModal(props) {
    return (
        <Modal
            {...props}
            size="md"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header closeButton>
                <Modal.Title id="contained-modal-title-vcenter">
                    Set Up Password
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
            <form>
                    <div class="mb-3">
                        <label for="otpInput" class="form-label">Enter new Password</label>
                        <input type="passsword" class="form-control" id="otpInput" maxlength="6" />
                    </div>
                    <div class="mb-3">
                        <label for="otpInput" class="form-label">confirm Password</label>
                        <input type="password" class="form-control" id="otpInput" maxlength="6" />
                    </div>
                </form>
                <h4>Instructions:</h4>
                <p>
                    Please enter your new password below. Your new password must be at least 8 characters long and contain a combination of letters, numbers, and special characters.
                </p>
                {/* Your form elements for entering the new password go here */}
            </Modal.Body>
            <Modal.Footer>
                {/* <Button onClick={props.onHide}>Close</Button> */}
                <Button variant="primary" onClick={props.onSubmit}>Submit</Button>
            </Modal.Footer>
        </Modal>
    );
}

function SignUpC() {
    
    const [secondModalShow, setSecondModalShow] = useState(false);
    const [newPasswordModalShow, setNewPasswordModalShow] = useState(false);
    // console.log(secondModalShow)
    const model = () => {
        setSecondModalShow(false);
        setNewPasswordModalShow(true);
    }
    
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleUsernameChange = (event) => {
        setUsername(event.target.value);
    };

    const handlePasswordChange = (event) => {
        setPassword(event.target.value);
    };

    const handleSubmit = (event) => {
        console.log("in submit")
        setSecondModalShow(true)
        event.preventDefault();
        
        // Here you can handle form submission, e.g., sending data to a server
        console.log('Username:', username);
        console.log('Password:', password);
    };

    return (
        <>
           <NavScrollExample />
            <Container className='my-5'>
                <Row className='justify-content-center gap-2'>
                    <Col lg={6} md={8} className='d-none d-sm-none d-md-none d-lg-block'>
                        <img src={img} alt="shdsvh" className='img-fluid h-100 rounded'/></Col>
                    <Col lg={{ span: 4, offset: 1 }} md={12} sm={12} style={{ flex: 1, paddingTop: '20px' }}>
                    
                        <div className="d-flex flex-column justify-content-center align-items-center addonsmsignup" >
                            <div className='w-100'>
                                <h3 class="text-center mb-4"><strong>SignUp-SubAdmin</strong></h3>
                                <h1>{secondModalShow}</h1>
                                <form>
                                    <div class="form-group mb-4 d-flex flex-column align-items-start gap-2 w-80">
                                        <label for="name">Name:</label>
                                        <input type="text" class="form-control" id="name" placeholder="Enter here" />
                                    </div>
                                    <div class="form-group mb-4 d-flex flex-column align-items-start gap-2">
                                        <label for="mobile">Mobile Number:</label>
                                        <input type="text" class="form-control" id="mobile" placeholder="Enter here" />
                                    </div>
                                    <div class="form-group mb-4 d-flex flex-column align-items-start gap-2">
                                        <label for="email">Email(Optional):</label>
                                        <input type="email" class="form-control" id="email" placeholder="Enter here" />
                                    </div>
                                    <div class="form-group mb-4 d-flex flex-column align-items-start gap-2">
                                        <label for="email">DL Number:</label>
                                        <input type="email" class="form-control" id="email" placeholder="Enter here" />
                                    </div>
                                    <div class="form-group mb-4 d-flex flex-column align-items-start gap-2">
                                        <label for="email">GST Number:</label>
                                        <input type="email" class="form-control" id="email" placeholder="Enter here" />
                                    </div>
                                    
                                    <Modal
                                        show={secondModalShow}
                                        onHide={() => setSecondModalShow(false)}
                                        size="md"
                                        aria-labelledby="contained-modal-title-vcenter"
                                        centered
                                    >
                                        <Modal.Header closeButton>
                                            <Modal.Title id="contained-modal-title-vcenter">
                                                Verify OTP
                                            </Modal.Title>
                                        </Modal.Header>
                                        <Modal.Body>
                                            <p>A verification code has been sent to your phone number ending in XXXX789. Please enter the code below to continue.</p>
                                            <form>
                                                <div class="mb-3">
                                                    <label for="otpInput" class="form-label">Verification Code</label>
                                                    <input type="text" class="form-control" id="otpInput" maxlength="6" placeholder="Enter 6-digit code" />
                                                </div>
                                            <button type="submit" class="btn btn-primary" >Verify</button> 
                                         </form>
                                            <p class="mt-3 text-muted">Didn't receive the code? <a href="#">Request a new code</a></p>
                                        </Modal.Body>
                                        <Modal.Footer>
                                            <Button onClick={() => model(true)}>Verify</Button>
                                        </Modal.Footer>
                                    </Modal>
                                    <NewPasswordModal
                                        show={newPasswordModalShow}
                                        onHide={() => setNewPasswordModalShow(false)}
                                        onSubmit={() => {
                                            console.log('New password submitted');
                                            setNewPasswordModalShow(false);
                                        }}
                                    /> 
                                    <div class="form-group d-flex justify-content-center mt-5">
                                        <button type="submit" class="btn btn-primary btn-lg mx-auto w-50 rounded-pill" onClick={handleSubmit}>Next</button>
                                    </div>
                                   
                        
                                </form>
                                </div>
                          
                        </div>
                    </Col>
                </Row>
            </Container>
            <Footer />
        </>
    );
}

export default SignUpC;
import React, { useState, useEffect } from "react";
import axios from "axios";
import NavSub from "./NavSub";

const Orders = () => {
    const [data, setData] = useState();

    useEffect(() => {
        const fetchOrders = async () => {
            try {
                const response = await axios.get("http://localhost:8090/entry");
                const filteredOrders = response.data.filter(order => order.Type === "User" && order.orders && order.orders.items[0].shopDetails.shopName === JSON.parse(localStorage.getItem("usname")) && order.orders.items[0].status !== "delivered");
                setData(filteredOrders);
            } catch (error) {
                console.error("Error fetching orders:", error);
            }
        };

        fetchOrders();
    }, []);
    const id = JSON.parse(localStorage.getItem("id"));

    const handleOrderDelivery = async (orderId) => {
        console.log(orderId)
        try {
            const updatedData = data.map(user => {
                if (user._id === orderId) {
                    const updatedItems = user.orders.items.map(item => {
                        return { ...item, status: "delivered" };
                    });
                    return { ...user, orders: { ...user.orders, items: updatedItems } };
                }
                return user;
            });
            setData(updatedData);
            // console.log(updatedData[0].orders)
            const push = updatedData[0].orders;
            await axios.post("http://localhost:8090/entryym", { id: orderId, push });

            alert("Data submitted successfully");
        } catch (error) {
            console.error("Error delivering order:", error);
        }
    };

    return (
        <div>
            <NavSub />
            <h1 className="text-center my-4">Orders</h1>
            <div className="row justify-content-center">
                {Array.isArray(data) && data.length > 0 ? (
                    data.map(user => (
                        <div key={user._id} className="col-md-4 mb-4">
                            <div className="card">
                                <div className="card-body">
                                    <h5 className="card-title">{user.Name}</h5>
                                    <p className="card-text">Email: {user.Email}</p>
                                    <p className="card-text">Mobile: {user.mobile}</p>
                                    <h6>Ordered Items:</h6>
                                    <ul>
                                        {user.orders && user.orders.items && user.orders.items.map(item => (
                                            <li key={item.medicine}>
                                                {item.medicine} - {item.quantity} quantity
                                            </li>
                                        ))}
                                    </ul>
                                    <button onClick={() => handleOrderDelivery(user._id)} className="btn btn-primary">Accept and Send</button>
                                </div>
                            </div>
                        </div>
                    ))
                ) : (
                    <div div className="row justify-content-center">

                        No orders found.
                    </div>
                )}
            </div>
        </div>
    );
};

export default Orders;

import React, { useEffect, useState } from "react";
import NavScrollExample from "./NavScrollExample";
import axios from "axios";
import img from '../Assets/reactangle.png';

const Ucart = () => {
    const [cart, setCart] = useState([]);
    const [orderHistory, setOrderHistory] = useState([]);
    const [userId, setUserId] = useState(null);

    useEffect(() => {
        const savedCart = JSON.parse(localStorage.getItem('cart')) || [];
        setCart(savedCart);
        const id = JSON.parse(localStorage.getItem("id"));
        setUserId(id);
        fetchCartData(id);
    }, []);

    const fetchCartData = async (id) => {
        try {
            const response = await axios.get(`http://localhost:8090/entry/${id}`);
            setCart(response.data.cart);
            setOrderHistory(response.data.orders.items);
        } catch (error) {
            console.error("Error fetching cart data:", error);
        }
    };

    const postCartData = async (updatedCart) => {
        try {
            await axios.post("http://localhost:8090/updateCart", { id: userId, updatedCart });
            alert("Data submitted successfully");
        } catch (error) {
            console.error("Error submitting data:", error);
            alert("Failed to submit data. Please try again.");
        }
    };

    const proceedToCheckout = async () => {
        try {
            await axios.post("http://localhost:8090/placeOrder", { userId, order: cart });
            setCart([]);
            alert("Order placed successfully!");
        } catch (error) {
            console.error("Error placing order:", error);
            alert("Failed to place order. Please try again.");
        }
        postCartData([]);
    };

    return (
        <>
            <NavScrollExample />
            <div className="container-fluid homestart">
                <img src={img} alt='image' className="imag" />
                <div className="home">
                    <p className="d-flex justify-content-center" style={{ fontSize: '70px' }}>Cart</p>
                    <div>
                        <h2>Shopping Cart</h2>
                        {cart.length === 0 ? (
                            <p>Your cart is empty.</p>
                        ) : (
                            <div className="row cartng justify-content-around align-items-center mx-2">
                                {cart.map((item, index) => (
                                    <div key={index} className="col-md-4 mb-3">
                                        <div className="card">
                                            <div className="card-body">
                                                <p className="cart-item-name">{item.medicine}</p>
                                                <p>Price: ${item.price}</p>
                                                <p>Quantity: {item.quantity}</p>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                                <div className="col-md-12 d-flex  justify-content-around align-items-center">
                                    <button onClick={proceedToCheckout} className="btn btn-success">Proceed to Checkout</button>
                                </div>
                            </div>
                        )}
                    </div>
                    <div>
                        <h2 className="text-center">Order History</h2>
                        {orderHistory.length > 0 ? (
                            <div className="row justify-content-center">
                                {orderHistory.map((user, index) => (
                                    <div key={index} className="col-md-2 mb-4">
                                        <div className="card">
                                            <div className="card-body text-center">
                                                <h5 className="card-title">{user.ShopName}</h5>
                                                {user.status ? (
                                                    <p className="card-text">Status: {user.status}</p>
                                                ) : (
                                                    <p className="card-text">Order Placed</p>
                                                )}

                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="row justify-content-center">
                                No orders found.
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
};

export default Ucart;

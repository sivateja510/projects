import React, { useContext, useEffect } from "react";
import NavSub from "./NavSub";
import { useState } from "react";
import { Button } from 'react-bootstrap';
import Footer from "./Footer";
import img from '../Assets/reactangle.png';
import axios from "axios";

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash, faCartPlus } from '@fortawesome/free-solid-svg-icons';

import Modal from 'react-bootstrap/Modal';
import { useNavigate } from "react-router-dom";
const pageSize = 8;
function MyVerticallyCenteredModall(props) {
    const data = JSON.parse(localStorage.getItem("Data"));
    const [formData, setFormData] = useState({
        id: data._id,
        Name: data.Name,
        Email: data.Email,
        Address: data.Address,
        DL: data.DL,
        GST: data.GST,
        Mobile: data.Mobile
    });

    const handleChange = (event) => {
        const { name, value } = event.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };




    const handleSubmit = (event) => {
        event.preventDefault();
        window.alert(JSON.stringify(formData));
        // localStorage.setItem("Data",formData)
        axios.post(`http://localhost:8090/entryy`, formData)
            .then((response) => {
                console.log(formData);
                // console.log("Form submitted with data:", formData);
                window.location.reload();
            })
            .catch((error) => {
                console.error("Error ", error);
            });
        props.onHide();
    };



    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header closeButton>
                <Modal.Title id="contained-modal-title-vcenter">
                    Edit details
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                        <label htmlFor="nameInput" className="form-label">Name</label>
                        <input type="text" className="form-control" id="nameInput" name="Name" value={formData.Name} onChange={handleChange} placeholder="Your Name" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="emailInput" className="form-label">Email</label>
                        <input type="email" className="form-control" id="emailInput" name="Email" value={formData.Email} onChange={handleChange} placeholder="Your Email Address" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="addressInput" className="form-label">Address</label>
                        <input type="text" className="form-control" id="addressInput" name="Address" value={formData.Address} onChange={handleChange} placeholder="Your Address" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="dlInput" className="form-label">Distributor License Number</label>
                        <input type="text" className="form-control" id="dlInput" name="DL" value={formData.DL} onChange={handleChange} placeholder="Your DL Number" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="gstInput" className="form-label">GST Number</label>
                        <input type="text" className="form-control" id="gstInput" name="GST" value={formData.GST} onChange={handleChange} placeholder="Your GST Number" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="mobileInput" className="form-label">Mobile Number</label>
                        <input type="text" className="form-control" id="mobileInput" name="Mobile" value={formData.Mobile} onChange={handleChange} maxLength="10" placeholder="Your Mobile Number" />
                    </div>
                    <Button type="submit">Update</Button>
                </form>
            </Modal.Body>
        </Modal>

    );
}


function NewPasswordModal(props) {
    const [formData, setFormData] = useState({
        newPassword: "",
        confirmPassword: ""
    });

    const handleChange = (event) => {
        const { name, value } = event.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = (event) => {
        const data = JSON.parse(localStorage.getItem("Data"));
        event.preventDefault();
        if (formData.newPassword !== formData.Password) {
            console.log("Passwords do not match");
            return;
        }
        console.log("New Password:", formData.newPassword);
        console.log("Confirm Password:", formData.Password);
        setFormData({
            newPassword: "",
            Password: "",
            id: data.id
        });
        axios.post(`http://localhost:8090/entryy`, formData)
            .then((response) => {
                console.log(formData);
                console.log("Updated");
                console.log("Form submitted with data:", formData);
            })
            .catch((error) => {
                console.error("Error ", error);
            });
        props.onHide();
    };


    return (
        <Modal
            {...props}
            size="md"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <form onSubmit={handleSubmit}>
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Set up Password
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>

                    <div className="mb-3">
                        <label htmlFor="newPassword" className="form-label">Enter New Password</label>
                        <input
                            type="password"
                            className="form-control"
                            id="newPassword"
                            name="newPassword"
                            value={formData.newPassword}
                            onChange={handleChange}
                            maxLength="8"
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="confirmPassword" className="form-label">Confirm Password</label>
                        <input
                            type="password"
                            className="form-control"
                            id="Password"
                            name="Password"
                            value={formData.Password}
                            onChange={handleChange}
                            maxLength="8"
                        />
                    </div>

                    <h4>Instructions:</h4>
                    <p>
                        Please enter your new password below. Your new password must be at least 8 characters long and contain a combination of letters, numbers, and special characters.
                    </p>
                </Modal.Body>
                <Modal.Footer>
                    <Button onClick={props.onHide}>Close</Button>
                    <Button variant="primary" onClick={handleSubmit}>Submit</Button>
                </Modal.Footer>
            </form>
        </Modal>
    );
}

const SubHome = () => {
    const navigate = useNavigate();
    useEffect(() => {
        if (!localStorage.getItem('Data'))
            navigate('/Login');
    }, []);
    const [modalShown, setModalShown] = useState(false);
    const [newPasswordModalShow, setNewPasswordModalShow] = useState(false);
    // const { items, setItems } = useContext(Context);
    const handleCloseFirstModall = () => {
        setModalShown(false);
    };

    const [user, setUser] = useState([]);
    const [tabletDetails, setTabletDetails] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);

    useEffect(() => {
        const getUser = async () => {
            try {
                const id = JSON.parse(localStorage.getItem("id"));
                const response = await axios.get(`http://localhost:8090/entry/${id}`);
                setUser(response.data);
                setTabletDetails(response.data.Tablets);
            } catch (error) {
                console.error("Error fetching user data:", error);
            }
        };

        getUser();
    }, []);

    const pageSize = 10;
    const indexOfLastItem = currentPage * pageSize;
    const indexOfFirstItem = indexOfLastItem - pageSize;
    const currentTabletDetails = tabletDetails.slice(indexOfFirstItem, indexOfLastItem);

    const handlePageChange = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    // Render your component using currentTabletDetails and handlePageChange



    return (
        <>
            <NavSub />
            <div className="fluid-container homestart">
                <img src={img} alt='#' className="imag" />
                <div className="home">
                    <div className="container py-4 cont1">
                        <div class="row justify-content-between mx-2 py-2">
                            <div class="col-auto">
                                <strong>Details</strong>
                            </div>
                            <div class="col-auto">
                                <strong style={{ color: 'blue' }} onClick={() => setModalShown(true)}>Edit Details</strong>
                            </div>
                        </div>
                        <MyVerticallyCenteredModall
                            show={modalShown}
                            onHide={() => handleCloseFirstModall(true)}
                        />

                        <NewPasswordModal
                            show={newPasswordModalShow}
                            onHide={() => setNewPasswordModalShow(false)}
                            onSubmit={() => {
                                console.log('New password submitted');
                                setNewPasswordModalShow(false);
                            }}
                        />



                        <div class="row justify-content-around align-items-center mx-2">
                            {user && (
                                <>
                                    <div className="col-lg-4 col-md-5 col-sm-10 col-xs-8">
                                        <div className="mb-lg-0 mb-md-2 mb-sm-2 mb-xs-2 py-2">Name of Firm: <strong>{user.Name}</strong></div>
                                        <div className="mb-lg-0 mb-md-2 mb-sm-2 mb-xs-2 py-2">DL No: <strong>{user.DL}</strong></div>
                                    </div>
                                    <div className="col-lg-4 col-md-5 col-sm-10 col-xs-8">
                                        <div className="mb-lg-0 mb-md-2 mb-sm-2 mb-xs-2 py-2">Mobile No: <strong>{user.Mobile}</strong></div>
                                        <div className="mb-lg-0 mb-md-2 mb-sm-2 mb-xs-2 py-2">GST No: <strong>{user.GST}</strong></div>
                                    </div>
                                    <div className="col-lg-4 col-md-5 col-sm-10 col-xs-8">
                                        <div className="mb-lg-0 mb-md-2 mb-sm-2 mb-xs-2 py-2">Email ID: <strong>{user.Email}</strong></div>
                                        <div className="mb-lg-0 mb-md-2 mb-sm-2 mb-xs-2 py-2">Address: <strong>{user.place}</strong></div>
                                    </div>
                                </>
                            )}
                        </div>
                        <div class="row justify-content-between mx-2 py-2">
                            <div class="col-auto">
                                <strong style={{ color: "lightblue" }} onClick={() => setNewPasswordModalShow(true)}>forgot password</strong>
                            </div>

                        </div>

                    </div>
                    <div class="container py-4 cont2">
                        <h5 class="mb-4">Available Medicine</h5>
                        <div class="table-responsive">
                            <table class="table  table-bordered table-hover rounded custom-table">
                                <thead class="bg-primary text-white font-weight-bold">
                                    <tr>
                                        <th class="text-center">Name</th>
                                        <th class="text-center">Price</th>
                                        <th class="text-center">Details</th>
                                        <th class="text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {currentTabletDetails.map((tablet, index) => (
                                        <tr key={index}>
                                            <td class="text-center">{tablet.medicine}</td>
                                            <td class="text-center">{tablet.price}</td>
                                            <td class="text-center">{tablet.type}</td>
                                            {tablet.quantity > 0
                                             ? <td class="text-center">Available</td> :  <td class="text-center">
                                             <FontAwesomeIcon icon={faCartPlus}  />
                                         </td>}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                        <nav>
                            <ul class="pagination justify-content-center">
                                {Array.from({ length: Math.ceil(tabletDetails.length / pageSize) }).map((_, index) => (
                                    <li class={"page-item" + (index + 1 === currentPage ? " active" : "")} key={index + 1}>
                                        <button class="page-link" onClick={() => handlePageChange(index + 1)}>{index + 1}</button>
                                    </li>
                                ))}
                            </ul>
                        </nav>
                    </div>
                    <Footer />
                </div>
            </div>

        </>
    )
}
export default SubHome;
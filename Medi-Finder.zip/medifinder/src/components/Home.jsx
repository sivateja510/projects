import React, { useState, useEffect } from "react";
import './home.css';
import { Button, Row, Col, Container, Form } from 'react-bootstrap';
import Card from 'react-bootstrap/Card';
import img from '../Assets/reactangle.png';
import imgg from '../Assets/download.jpeg';
import medc from '../Assets/medc.jpg';
import Footer from "./Footer";
import NavScrollExample from "./NavScrollExample";
import axios from 'axios';
import { useNavigate } from "react-router-dom";

function Home() {
    const navigate = useNavigate();
    const [selectedLocations, setSelectedLocations] = useState([]);
    const [medicineName, setMedicineName] = useState('');
    const [diseaseName, setDiseaseName] = useState('');
    const [hospitalName, setHospitalName] = useState('');
    const [users, setUsers] = useState([]);

    useEffect(() => {
        getUsers();
    }, [selectedLocations, medicineName, diseaseName, hospitalName]);

    const getUsers = async () => {
        try {
            const response = await axios.get('http://localhost:8090/entry');
            setUsers(response.data);
        } catch (error) {
            console.error(error);
        }
    }

    const handleChange = (e) => {
        const { value, checked } = e.target;
        if (checked) {
            setSelectedLocations([...selectedLocations, value]);
        } else {
            setSelectedLocations(selectedLocations.filter(location => location !== value));
        }
    };

    const handleMedicineNameChange = (e) => {
        setMedicineName(e.target.value);
    };

    const handleDiseaseNameChange = (e) => {
        setDiseaseName(e.target.value);
    };

    const handleHospitalNameChange = (e) => {
        setHospitalName(e.target.value);
    };

    const handleSearch = () => {
        const filteredData = users.filter(data => {
            if (selectedLocations.length === 0 || selectedLocations.includes(data.place)) {
                const matchesMedicine = !medicineName || (data.Tablets && data.Tablets.some(tablet =>
                    tablet && tablet.medicine &&
                    tablet.medicine.toLowerCase().includes(medicineName.toLowerCase())
                ));

                const matchesDisease = !diseaseName || (data.diseases && data.diseases.some(disease => disease.name.toLowerCase().includes(diseaseName.toLowerCase())));

                const matchesHospitalName = !hospitalName || (data.Name && data.Name.toLowerCase().includes(hospitalName.toLowerCase()));

                return matchesMedicine && matchesDisease && matchesHospitalName;
            }
            return false;
        });

        const filteredNonUser = filteredData.filter(data => data.Type !== "User");

        return filteredNonUser;
    };

    return (
        <>
            <NavScrollExample />
            <div className="fluid-container homestart">
                <img src={img} alt='image' className="imag" />
                <div className="home">
                    <div className="container py-4 cont1">
                        <div className="row justify-content-around align-items-center mx-2">
                            <div className="col-lg-4 col-md-5 col-sm-10 col-xs-8">
                                <label htmlFor="medicineName" className="form-label labell">Medicine Name</label>
                                <input type="text" className="form-control" id="medicineName" placeholder="Enter Here.." style={{ backgroundColor: "#ececec" }} onChange={handleMedicineNameChange} />
                            </div>
                            <div className="col-lg-4 col-md-6 col-sm-10 col-xs-8">
                                <label htmlFor="diseaseName" className="form-label labell">Disease Name</label>
                                <input type="text" className="form-control" id="diseaseName" placeholder="Enter Here.." style={{ backgroundColor: "#ececec" }} onChange={handleDiseaseNameChange} />
                            </div>
                            <div className="col-lg-4 col-md-10 col-sm-10 col-xs-8">
                                <label htmlFor="hospitalName" className="form-label labell">Hospital / Shop Name</label>
                                <input type="text" className="form-control" id="hospitalName" placeholder="Enter Here.." style={{ backgroundColor: "#ececec" }} onChange={handleHospitalNameChange} />
                            </div>
                        </div>
                        <div className="d-flex align-items-center justify-content-center mt-4">
                            <button className="btn btn-primary btn-lg rounded-pill px-5" onClick={handleSearch}>Search</button>
                        </div>
                    </div>
                    <div className="container py-5 cont2">
                        <Row>
                            <Col md={2}>
                                <Container className="checkbox-container">
                                    <Form>
                                        <Form.Group controlId="formBasicCheckbox">
                                            {Array.from(new Set(users.map(user => user.place))).map((place, index) => (
                                                <Form.Check key={index} type="checkbox" label={place} value={place} onChange={handleChange} />
                                            ))}
                                        </Form.Group>
                                    </Form>
                                </Container>
                            </Col>
                            <Col md={10}>
                                <Container>
                                    <Row xs={1} md={2} lg={3} className="g-4">
                                        {handleSearch().filter(data => data.Type !== "Admin").map(data => (
                                            <Col key={data._id} xs={12} sm={6} md={4} lg={3}>
                                                <Card>
                                                    <>
                                                    <Card.Img variant="top" src={data.Pic} />
                                                        {/* {data.Type === "Shop" ? (
                                                            <Card.Img variant="top" src={medc} />
                                                        ) : (
                                                            <Card.Img variant="top" src={imgg} />
                                                        )} */}
                                                    </>

                                                    <Card.Body>
                                                        <Card.Title>{data.Name}</Card.Title>
                                                        <Card.Text>Type: {data.Type}</Card.Text>
                                                        <Button onClick={() => navigate(data.Type === "Shop" ? "/Shop" : "/Hospital", { state: data })}>Visit {data.Type}</Button>
                                                    </Card.Body>
                                                </Card>
                                            </Col>
                                        ))}

                                    </Row>
                                </Container>
                            </Col>
                        </Row>
                    </div>
                    <Footer />
                </div>
            </div>
        </>
    );
}

export default Home;

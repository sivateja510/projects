import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebook, faInstagram, faYoutube, faTwitter } from '@fortawesome/free-brands-svg-icons';
import 'bootstrap/dist/css/bootstrap.min.css';
import './home.css';

function Footer() {
  return (
    <footer className="footer bg-dark text-white py-3 ">
      <div className="container my-3">
        <div className="row justify-content-center">
        {/* <div className="col-lg-3"></div> */}
        <div className='col-lg-4 col-md-6 col-xs-12 d-flex flex-column justifu-content-center align-items-center'>
        
            <p className="text-white"><a href="https://www.facebook.com/" className="text-white me-2"><FontAwesomeIcon icon={faFacebook} /></a>Facebook</p>
            <p className="text-white"><a href="https://www.instagram.com/" className="text-white me-2"><FontAwesomeIcon icon={faInstagram} /></a>Instagram</p>
            <p className="text-white"><a href="https://www.youtube.com/" className="text-white me-2"><FontAwesomeIcon icon={faYoutube} /></a>YouTube</p>
            <p className="text-white"><a href="https://www.twitter.com/" className="text-white me-2"><FontAwesomeIcon icon={faTwitter} /></a>Twitter</p>
        </div>
        <div className='col-lg-4 col-md-6 col-xs-12 d-flex flex-column justifu-content-center align-items-center'>
        
        <a className="text-white my-2" href="#" style={{textDecoration:"none"}}>About Us</a>
        <a className="text-white my-2" href="#" style={{textDecoration:"none"}}>Media</a>
        <a className="text-white my-2" href="#" style={{textDecoration:"none"}}>Terms Of Service</a>
        <a className="text-white my-2" href="#" style={{textDecoration:"none"}}>Privacy Policy</a>
    </div>
    <div className='col-lg-4 col-md-6 col-xs-12 d-flex flex-column justifu-content-center align-items-center'>
        
        <a className="text-white my-2" href="#" style={{textDecoration:"none"}}>Contact Us</a>
        <a className="text-white my-2" href="#" style={{textDecoration:"none"}}>FAQ's</a>
        <a className="text-white my-2" href="#" style={{textDecoration:"none"}}>Report Issues</a>

    </div>
          
        </div>
        {/* <div className="row">
        <div className="col"></div>
          <div className="col text-left">
            <a href="https://www.instagram.com/" className="text-white mr-2"><FontAwesomeIcon icon={faInstagram} /></a>
            <span className="text-white">Instagram</span>
          </div>
          <div className="col text-left">
            <span className="text-white">Media</span>
          </div>
          <div className="col text-left">
            <span className="text-white">FAQ's</span>
          </div>
        </div>
        <div className="row">
        <div className="col"></div>
          <div className="col text-left">
            <a href="https://www.youtube.com/" className="text-white mr-2"><FontAwesomeIcon icon={faYoutube} /></a>
            <span className="text-white">YouTube</span>
          </div>
          <div className="col text-left">
            <span className="text-white">Terms of service</span>
          </div>
          <div className="col text-left">
            <span className="text-white">Report Issues</span>
          </div>
        </div>
        <div className="row">
        <div className="col"></div>
          <div className="col text-left">
            <a href="https://twitter.com/" className="text-white mr-2"><FontAwesomeIcon icon={faTwitter} /></a>
            <span className="text-white">Twitter</span>
          </div>
          <div className="col text-left">
            <span className="text-white">Policy</span>
          </div>
          <div className="col text-left">
          </div>
        </div> */}
      </div>
    </footer>
  );
}

export default Footer;

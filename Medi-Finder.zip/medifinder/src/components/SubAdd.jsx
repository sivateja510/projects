import React, { useState, useEffect } from "react";
import NavSub from "./NavSub";
import img from '../Assets/reactangle.png';
import Footer from "./Footer";
import axios from "axios";
import { Tab } from "bootstrap";

const SubAdd = () => {
    const [medicineOptions, setMedicineOptions] = useState([]); // State to hold medicine options
    const [selectedMedicine, setSelectedMedicine] = useState(""); // State to hold selected medicine
    const [type, setDetails] = useState("");
    const [price, setCompany] = useState("");
    const [quantity, setQuantity] = useState("");
    const [tableData, setTableData] = useState([]);
    const [existingData, setExistingData] = useState([]); // State to hold existing data from API
    const [showInputBars, setShowInputBars] = useState(false); // State to track whether to show input bars or buttons
    const [isAddingNew, setIsAddingNew] = useState(false); // State to track if adding new or updating existing entry

    // Function to fetch existing data from API
    const getExistingData = async () => {
        try {
            const id = JSON.parse(localStorage.getItem("id"));
            const response = await axios.get(`http://localhost:8090/entry/${id}`);
            setExistingData(response.data.Tablets || []);
            // Extracting unique medicine names for select options
            const medicineNames = response.data.Tablets.map(item => item.medicine);
            const uniqueMedicineNames = [...new Set(medicineNames)];
            setMedicineOptions(uniqueMedicineNames);
        } catch (error) {
            console.error("Error fetching existing data:", error);
        }
    };

    useEffect(() => {
        getExistingData();
    }, []);

    const handleMedicineSelect = (medicineName) => {
        setSelectedMedicine(medicineName);
        // Find the selected medicine details from existing data
        const selectedMedicineData = existingData.find(item => item.medicine === medicineName);
        if (selectedMedicineData) {
            setDetails(selectedMedicineData.type);
            setCompany(selectedMedicineData.price);
            setQuantity(selectedMedicineData.quantity);
        }
    };

    const handleAdd = () => {
        // Validate inputs
        if (!selectedMedicine || !type || !price || !quantity) {
            alert("Please fill in all fields");
            return;
        }
    
        // Check if the medicine already exists in tableData
        const existingIndex = tableData.findIndex(item => item.medicine === selectedMedicine);
    
        if (existingIndex !== -1) {
            // If the medicine exists, update the quantity
            const updatedTableData = [...tableData];
            updatedTableData[existingIndex].quantity += parseInt(quantity);
            setTableData(updatedTableData);
        } else {
            // If the medicine doesn't exist, add it as new
            const newData = { medicine: selectedMedicine, type, price, quantity: parseInt(quantity) };
            setTableData(prevData => [...prevData, newData]);
        }
    
        // Reset input fields
        setSelectedMedicine("");
        setDetails("");
        setCompany("");
        setQuantity("");
    };
    
    const handleDelete = (index) => {
        const updatedTableData = [...tableData];
        updatedTableData.splice(index, 1);
        setTableData(updatedTableData);
    };
    const handleSubmitr = async () => {
        const bef = existingData || [];
        const Tabletsr = tableData.map(({ id, ...rest }) => rest);
        const updatedTablets = [];
    
        // Merge existing data and new data, updating quantity if medicine already exists
        bef.forEach(existingItem => {
            const index = Tabletsr.findIndex(item => item.medicine === existingItem.medicine);
            if (index !== -1) {
                // Update quantity for existing medicine
                Tabletsr[index].quantity += existingItem.quantity;
            } else {
                // Add existing medicine if not found in new data
                Tabletsr.push(existingItem);
            }
        });
        console.log(Tabletsr)
        try {
            const id = JSON.parse(localStorage.getItem("id"));
            await axios.post("http://localhost:8090/entryxx", { id, Tablets: Tabletsr });
            alert("Data submitted successfully");
        } catch (error) {
            console.error("Error submitting data:", error);
            alert("Failed to submit data. Please try again.");
        }
    };
    


    return (
        <>
            <NavSub />
            <div className="fluid-container homestart">
                <img src={img} alt='image' className="imag" />
                <div className="home">
                    <div className="container py-4 cont1">
                        {!showInputBars ? (
                            <div className="d-flex align-items-center justify-content-center mt-4">
                                <button className="btn btn-primary btn-sm rounded-pill px-5 mx-2" onClick={() => { setShowInputBars(true); setIsAddingNew(true); }}>Add New</button>
                                <button className="btn btn-primary btn-sm rounded-pill px-5 mx-2" onClick={() => { setShowInputBars(true); setIsAddingNew(false); }}>Update Existing</button>
                            </div>
                        ) : (
                            <>
                                <div className="row justify-content-around align-items-center mx-2">
                                    <div className="col-lg-3 col-md-4 col-sm-10 col-xs-8">
                                        <label htmlFor="medicine" className="form-label labell">Medicine</label>
                                        {isAddingNew ? (
                                            <input type="text" className="form-control" id="medicine" placeholder="Enter Here.." style={{ backgroundColor: "#ececec" }} value={selectedMedicine} onChange={(e) => setSelectedMedicine(e.target.value)} />
                                        ) : (
                                            <select className="form-control" id="medicine" value={selectedMedicine} onChange={(e) => handleMedicineSelect(e.target.value)}>
                                                <option value="">Select Medicine</option>
                                                {medicineOptions.map((medicineName, index) => (
                                                    <option key={index} value={medicineName}>{medicineName}</option>
                                                ))}
                                            </select>
                                        )}
                                    </div>
                                    <div className="col-lg-3 col-md-4 col-sm-10 col-xs-8">
                                        <label htmlFor="details" className="form-label labell">Type</label>
                                        <input type="text" className="form-control" id="details" placeholder="Enter Here.." style={{ backgroundColor: "#ececec" }} value={type} onChange={(e) => setDetails(e.target.value)} />
                                    </div>
                                    <div className="col-lg-3 col-md-4 col-sm-10 col-xs-8">
                                        <label htmlFor="company" className="form-label labell">Price</label>
                                        <input type="text" className="form-control" id="price" placeholder="Enter Here.." style={{ backgroundColor: "#ececec" }} value={price} onChange={(e) => setCompany(e.target.value)} />
                                    </div>
                                    <div className="col-lg-3 col-md-4 col-sm-10 col-xs-8">
                                        <label htmlFor="quantity" className="form-label labell">Quantity</label>
                                        <input type="text" className="form-control" id="quantity" placeholder="Enter Here.." style={{ backgroundColor: "#ececec" }} value={quantity} onChange={(e) => setQuantity(e.target.value)} />
                                    </div>
                                </div>
                                <div className="d-flex align-items-center justify-content-center mt-4">
                                    <button className="btn btn-primary btn-sm rounded-pill px-5" onClick={handleAdd}>Add</button>
                                    <button className="btn btn-primary btn-sm rounded-pill px-5 mx-2" onClick={() => setShowInputBars(false)}>Hide Input Bars</button>
                                </div>
                            </>
                        )}
                    </div>
                    {/* Your table rendering code */}
                    <div className="container py-4 cont2">
                        <h5 className="mb-4">Medicines Added</h5>
                        <div className="table-responsive">
                            <table className="table table-bordered table-hover rounded custom-table">
                                <thead className="bg-primary text-white font-weight-bold">
                                    <tr>
                                        <th className="text-center">Name</th>
                                        <th className="text-center">Type</th>
                                        <th className="text-center">price</th>
                                        <th className="text-center">Quantity</th>
                                        <th className="text-center">Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {tableData.map((data, index) => (
                                        <tr key={index}>
                                            <td className="text-center">{data.medicine}</td>
                                            <td className="text-center">{data.type}</td>
                                            <td className="text-center">{data.price}</td>
                                            <td className="text-center">{data.quantity}</td>
                                            <td className="text-center">
                                                <button className="btn btn-danger btn-sm" onClick={() => handleDelete(index)}>Delete</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div className="d-flex align-items-center justify-content-center m-2">
                        <button className="btn btn-primary btn-sm rounded-pill px-5" onClick={handleSubmitr}>Submit</button>
                    </div>
                    <Footer />
                </div>
            </div>
        </>
    );
};

export default SubAdd;

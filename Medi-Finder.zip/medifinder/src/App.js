import logo from './logo.svg';
import './App.css';
import NavBar from './components/NavScrollExample.jsx';
import Login from './components/Login.jsx';
import { BrowserRouter as Router, Route, Routes, BrowserRouter } from 'react-router-dom';
import Signup from './components/Signup.jsx';
import NavScrollExample from './components/NavScrollExample.jsx';
import Home from './components/Home.jsx';
import Footer from './components/Footer.jsx';
import SignUpC from './components/SignUpC.jsx';
import SubHome from './components/SubHome.jsx';
import SubAdd from './components/SubAdd.jsx';
import Cart from './components/Cart.jsx';
import SubShow from './components/SubShow.jsx';
import Seperate from './components/Seperate.jsx';
import Shop from './components/Shop.jsx';
import Hospital from './components/Hospital.jsx';
import Ucart from './components/Ucart.jsx';
import Orders from './components/Orders.jsx';
import Sell from './components/Sell.jsx';
import ManageSubAdmins from './components/ManageSubAdmins.jsx';
import ManageProducts from './components/ManageProducts.jsx';
import Dashboard from './components/Dashboard.jsx';

function App() {

  return (
    <>

      < Router>

        <Routes>
          <Route path='/login' element={<Login />} />
          <Route path='/signup' element={<Signup />} />
          <Route path='/SignUpC' element={<SignUpC />} />
          <Route path='/SubAdd' element={<SubAdd />} />
          <Route path='/Shop' element={<Shop />} />
          <Route path='/Sell' element={<Sell />} />
          <Route path='/' element={<Home />} />
          <Route path='/SubHome' element={<SubHome />} />
          <Route path='/Cart' element={<Cart />} />
          <Route path='/SubShow' element={<SubShow />} />
          <Route path='/Sep' element={<Seperate />} />
          <Route path='/Hospital' element={<Hospital />} />
          <Route path='/Ucart' element={<Ucart />} />
          <Route path='/Collect' element={<Orders />} />
          <Route path='/AdminDashboard' element={<Dashboard />} />
          <Route path='/ManageUsers' element={<ManageSubAdmins />} />
          <Route path='/ManageProducts' element={<ManageProducts />} />
        </Routes>

      </Router>
    </>
  );
}

export default App;
